import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Users, Package, ShoppingCart, DollarSign, 
  AlertTriangle, TrendingUp, Calendar, FileText 
} from "lucide-react";
import { LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Link } from "wouter";

export default function Home() {
  const { data: stats, isLoading } = trpc.dashboard.stats.useQuery();
  const { data: salesStats } = trpc.sales.stats.useQuery();
  const { data: pendingAccounts = [] } = trpc.accounts.list.useQuery();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Carregando dashboard...</p>
        </div>
      </div>
    );
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value / 100);
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  };

  // Preparar dados para o gráfico de pizza de formas de pagamento
  const paymentMethodData = salesStats?.salesByPaymentMethod.map((item: any) => ({
    name: item.paymentMethod,
    value: item.total / 100,
  })) || [];

  const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6"];

  const upcomingDueAccounts = pendingAccounts.filter((account: any) => {
    if (account.isPaid) return false;
    const dueDate = new Date(account.dueDate);
    const now = new Date();
    const nextWeek = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    return dueDate >= now && dueDate <= nextWeek;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground mt-2">
          Visão geral do seu negócio
        </p>
      </div>

      {/* Main Statistics Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Clientes</CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalClients || 0}</div>
            <p className="text-xs text-muted-foreground">clientes cadastrados</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Produtos Cadastrados</CardTitle>
            <Package className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalProducts || 0}</div>
            <p className="text-xs text-muted-foreground">itens no catálogo</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Vendas</CardTitle>
            <ShoppingCart className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalSales || 0}</div>
            <p className="text-xs text-muted-foreground">vendas realizadas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
            <DollarSign className="h-4 w-4 text-emerald-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(stats?.financialStats.totalRevenue || 0)}
            </div>
            <p className="text-xs text-muted-foreground">em vendas</p>
          </CardContent>
        </Card>
      </div>

      {/* Financial Summary */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Despesas Totais</CardTitle>
            <TrendingUp className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {formatCurrency(stats?.financialStats.totalExpenses || 0)}
            </div>
            <p className="text-xs text-muted-foreground">gastos registrados</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Lucro do Período</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${(stats?.financialStats.profit || 0) >= 0 ? "text-green-600" : "text-red-600"}`}>
              {formatCurrency(stats?.financialStats.profit || 0)}
            </div>
            <p className="text-xs text-muted-foreground">receita - despesas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Contas Pendentes</CardTitle>
            <FileText className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency((stats?.financialStats.pendingReceivables || 0) + (stats?.financialStats.pendingPayables || 0))}
            </div>
            <p className="text-xs text-muted-foreground">a receber e pagar</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Vendas por Forma de Pagamento</CardTitle>
            <CardDescription>Distribuição total</CardDescription>
          </CardHeader>
          <CardContent>
            {paymentMethodData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={paymentMethodData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {paymentMethodData.map((_: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => formatCurrency(value * 100)} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                Nenhuma venda registrada ainda
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Alerts Section */}
      <div className="grid gap-4 md:grid-cols-2">
        {/* Low Stock Alert */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-orange-600" />
              <CardTitle>Alertas de Estoque</CardTitle>
            </div>
            <CardDescription>
              {stats?.lowStockCount || 0} produto{(stats?.lowStockCount || 0) !== 1 ? "s" : ""} com estoque baixo
            </CardDescription>
          </CardHeader>
          <CardContent>
            {stats?.lowStockProducts && stats.lowStockProducts.length > 0 ? (
              <div className="space-y-2">
                {stats.lowStockProducts.map((product: any) => (
                  <div key={product.id} className="flex items-center justify-between p-2 border rounded-lg">
                    <div>
                      <p className="font-medium">{product.name}</p>
                      <p className="text-sm text-muted-foreground">
                        Quantidade: {product.quantity}
                      </p>
                    </div>
                    <Badge variant="destructive">Baixo</Badge>
                  </div>
                ))}
                <Link href="/estoque">
                  <a className="text-sm text-primary hover:underline block mt-2">
                    Ver todos os produtos →
                  </a>
                </Link>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                Nenhum produto com estoque baixo
              </p>
            )}
          </CardContent>
        </Card>

        {/* Upcoming Due Accounts */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-blue-600" />
              <CardTitle>Contas a Vencer</CardTitle>
            </div>
            <CardDescription>
              Próximos 7 dias
            </CardDescription>
          </CardHeader>
          <CardContent>
            {upcomingDueAccounts.length > 0 ? (
              <div className="space-y-2">
                {upcomingDueAccounts.slice(0, 5).map((account: any) => (
                  <div key={account.id} className="flex items-center justify-between p-2 border rounded-lg">
                    <div>
                      <p className="font-medium">{account.description}</p>
                      <p className="text-sm text-muted-foreground">
                        Vencimento: {formatDate(account.dueDate)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">{formatCurrency(account.amount)}</p>
                      <Badge variant={account.type === "pagar" ? "destructive" : "default"}>
                        {account.type === "pagar" ? "Pagar" : "Receber"}
                      </Badge>
                    </div>
                  </div>
                ))}
                <Link href="/financeiro">
                  <a className="text-sm text-primary hover:underline block mt-2">
                    Ver todas as contas →
                  </a>
                </Link>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                Nenhuma conta a vencer nos próximos 7 dias
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Sales and Requests */}
      <div className="grid gap-4 md:grid-cols-2">
        {/* Recent Sales */}
        <Card>
          <CardHeader>
            <CardTitle>Vendas Recentes</CardTitle>
            <CardDescription>Últimas 5 vendas registradas</CardDescription>
          </CardHeader>
          <CardContent>
            {stats?.recentSales && stats.recentSales.length > 0 ? (
              <div className="space-y-3">
                {stats.recentSales.map((sale: any) => (
                  <div key={sale.id} className="flex items-center justify-between p-2 border rounded-lg">
                    <div>
                      <p className="font-medium">Venda #{sale.id}</p>
                      <p className="text-sm text-muted-foreground">
                        {formatDate(sale.saleDate)} - {sale.paymentMethod}
                      </p>
                    </div>
                    <p className="font-semibold text-green-600">
                      {formatCurrency(sale.totalAmount)}
                    </p>
                  </div>
                ))}
                <Link href="/vendas">
                  <a className="text-sm text-primary hover:underline block mt-2">
                    Ver todas as vendas →
                  </a>
                </Link>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                Nenhuma venda registrada ainda
              </p>
            )}
          </CardContent>
        </Card>

        {/* Recruitment Alerts */}
        <Card>
          <CardHeader>
            <CardTitle>Solicitações e Reuniões</CardTitle>
            <CardDescription>Atividades pendentes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 border rounded-lg bg-orange-50 dark:bg-orange-950/20">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-orange-600" />
                  <div>
                    <p className="font-medium">Solicitações Pendentes</p>
                    <p className="text-sm text-muted-foreground">Aguardando análise</p>
                  </div>
                </div>
                <Badge variant="outline" className="text-lg">
                  {stats?.pendingRequests || 0}
                </Badge>
              </div>

              <div className="flex items-center justify-between p-3 border rounded-lg bg-blue-50 dark:bg-blue-950/20">
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-blue-600" />
                  <div>
                    <p className="font-medium">Reuniões Agendadas</p>
                    <p className="text-sm text-muted-foreground">Próximas reuniões</p>
                  </div>
                </div>
                <Badge variant="outline" className="text-lg">
                  {stats?.upcomingMeetings || 0}
                </Badge>
              </div>

              <Link href="/recrutamento">
                <a className="text-sm text-primary hover:underline block mt-2">
                  Gerenciar recrutamento →
                </a>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
