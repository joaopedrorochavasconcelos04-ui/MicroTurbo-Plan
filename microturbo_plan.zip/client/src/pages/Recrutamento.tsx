import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Edit, Trash2, Mail, Calendar, Eye, Users, Clock, CheckCircle2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const STATUS_LABELS = {
  pendente: "Pendente",
  em_analise: "Em Análise",
  agendado: "Agendado",
  concluido: "Concluído",
};

const MEETING_STATUS_LABELS = {
  agendada: "Agendada",
  realizada: "Realizada",
  cancelada: "Cancelada",
};

export default function Recrutamento() {
  const [isCreateRequestOpen, setIsCreateRequestOpen] = useState(false);
  const [isCreateMeetingOpen, setIsCreateMeetingOpen] = useState(false);
  const [viewingRequest, setViewingRequest] = useState<number | null>(null);
  const [editingRequest, setEditingRequest] = useState<number | null>(null);
  const [editingMeeting, setEditingMeeting] = useState<number | null>(null);
  
  const utils = trpc.useUtils();
  const { data: requests = [] } = trpc.recruitment.list.useQuery();
  const { data: meetings = [] } = trpc.meetings.list.useQuery();
  const { data: viewedRequest } = trpc.recruitment.getById.useQuery(
    { id: viewingRequest! },
    { enabled: viewingRequest !== null }
  );
  
  const createRequestMutation = trpc.recruitment.create.useMutation({
    onSuccess: () => {
      utils.recruitment.list.invalidate();
      setIsCreateRequestOpen(false);
      toast.success("Solicitação registrada com sucesso!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao registrar solicitação");
    },
  });
  
  const updateRequestMutation = trpc.recruitment.update.useMutation({
    onSuccess: () => {
      utils.recruitment.list.invalidate();
      setEditingRequest(null);
      toast.success("Solicitação atualizada com sucesso!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao atualizar solicitação");
    },
  });
  
  const deleteRequestMutation = trpc.recruitment.delete.useMutation({
    onSuccess: () => {
      utils.recruitment.list.invalidate();
      toast.success("Solicitação excluída com sucesso!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao excluir solicitação");
    },
  });

  const createMeetingMutation = trpc.meetings.create.useMutation({
    onSuccess: () => {
      utils.meetings.list.invalidate();
      setIsCreateMeetingOpen(false);
      toast.success("Reunião agendada com sucesso!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao agendar reunião");
    },
  });
  
  const updateMeetingMutation = trpc.meetings.update.useMutation({
    onSuccess: () => {
      utils.meetings.list.invalidate();
      setEditingMeeting(null);
      toast.success("Reunião atualizada com sucesso!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao atualizar reunião");
    },
  });
  
  const deleteMeetingMutation = trpc.meetings.delete.useMutation({
    onSuccess: () => {
      utils.meetings.list.invalidate();
      toast.success("Reunião excluída com sucesso!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao excluir reunião");
    },
  });

  const handleCreateRequest = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    createRequestMutation.mutate({
      clientName: formData.get("clientName") as string,
      clientContact: formData.get("clientContact") as string,
      serviceRequested: formData.get("serviceRequested") as string,
      description: formData.get("description") as string,
    });
  };

  const handleUpdateRequest = (e: React.FormEvent<HTMLFormElement>, requestId: number) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    updateRequestMutation.mutate({
      id: requestId,
      clientName: formData.get("clientName") as string,
      clientContact: formData.get("clientContact") as string,
      serviceRequested: formData.get("serviceRequested") as string,
      description: formData.get("description") as string,
      status: formData.get("status") as any,
    });
  };

  const handleCreateMeeting = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    createMeetingMutation.mutate({
      recruitmentRequestId: formData.get("recruitmentRequestId") ? Number(formData.get("recruitmentRequestId")) : undefined,
      title: formData.get("title") as string,
      meetingDate: new Date(formData.get("meetingDate") as string),
      location: formData.get("location") as string,
      description: formData.get("description") as string,
    });
  };

  const handleUpdateMeeting = (e: React.FormEvent<HTMLFormElement>, meetingId: number) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    updateMeetingMutation.mutate({
      id: meetingId,
      title: formData.get("title") as string,
      meetingDate: new Date(formData.get("meetingDate") as string),
      location: formData.get("location") as string,
      description: formData.get("description") as string,
      status: formData.get("status") as any,
    });
  };

  const generateMailtoLink = (request: typeof viewedRequest) => {
    if (!request) return "#";
    
    const subject = encodeURIComponent(`Reunião - ${request.serviceRequested}`);
    const body = encodeURIComponent(
      `Olá ${request.clientName},\n\n` +
      `Gostaria de agendar uma reunião para discutir sobre: ${request.serviceRequested}\n\n` +
      `Descrição: ${request.description || "N/A"}\n\n` +
      `Aguardo seu retorno.\n\n` +
      `Atenciosamente,\nEquipe MicroTurbo Plan`
    );
    
    return `mailto:${request.clientContact}?subject=${subject}&body=${body}`;
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const pendingRequests = requests.filter(r => r.status === "pendente" || r.status === "em_analise");
  const upcomingMeetings = meetings.filter(m => m.status === "agendada" && new Date(m.meetingDate) >= new Date());

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Recrutamento de Profissionais</h1>
        <p className="text-muted-foreground mt-2">
          Gerencie solicitações de clientes e reuniões agendadas
        </p>
      </div>

      {/* Statistics Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Solicitações Pendentes</CardTitle>
            <Users className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingRequests.length}</div>
            <p className="text-xs text-muted-foreground">aguardando análise</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Reuniões Agendadas</CardTitle>
            <Calendar className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{upcomingMeetings.length}</div>
            <p className="text-xs text-muted-foreground">próximas reuniões</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Solicitações</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{requests.length}</div>
            <p className="text-xs text-muted-foreground">registradas no sistema</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="requests" className="space-y-4">
        <TabsList>
          <TabsTrigger value="requests">Solicitações</TabsTrigger>
          <TabsTrigger value="meetings">Reuniões Agendadas</TabsTrigger>
        </TabsList>

        <TabsContent value="requests" className="space-y-4">
          <div className="flex justify-end">
            <Dialog open={isCreateRequestOpen} onOpenChange={setIsCreateRequestOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Nova Solicitação
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <form onSubmit={handleCreateRequest}>
                  <DialogHeader>
                    <DialogTitle>Registrar Solicitação</DialogTitle>
                    <DialogDescription>
                      Preencha os dados da solicitação do cliente
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                      <Label htmlFor="clientName">Nome do Cliente *</Label>
                      <Input id="clientName" name="clientName" required />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="clientContact">Contato (Email/Telefone) *</Label>
                      <Input id="clientContact" name="clientContact" required />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="serviceRequested">Serviço Solicitado *</Label>
                      <Input id="serviceRequested" name="serviceRequested" required />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="description">Descrição</Label>
                      <Textarea id="description" name="description" rows={3} />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setIsCreateRequestOpen(false)}>
                      Cancelar
                    </Button>
                    <Button type="submit" disabled={createRequestMutation.isPending}>
                      {createRequestMutation.isPending ? "Salvando..." : "Salvar"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Solicitações de Clientes</CardTitle>
              <CardDescription>
                Total de {requests.length} solicitação{requests.length !== 1 ? "ões" : ""} registrada{requests.length !== 1 ? "s" : ""}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {requests.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  Nenhuma solicitação registrada ainda
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Cliente</TableHead>
                        <TableHead>Contato</TableHead>
                        <TableHead>Serviço</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {requests.map((request) => (
                        <TableRow key={request.id}>
                          <TableCell className="font-medium">{request.clientName}</TableCell>
                          <TableCell>{request.clientContact}</TableCell>
                          <TableCell>{request.serviceRequested}</TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                request.status === "concluido"
                                  ? "default"
                                  : request.status === "agendado"
                                  ? "secondary"
                                  : "outline"
                              }
                            >
                              {STATUS_LABELS[request.status as keyof typeof STATUS_LABELS]}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              <Dialog open={viewingRequest === request.id} onOpenChange={(open) => !open && setViewingRequest(null)}>
                                <DialogTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => setViewingRequest(request.id)}
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="sm:max-w-[500px]">
                                  <DialogHeader>
                                    <DialogTitle>Detalhes da Solicitação</DialogTitle>
                                    <DialogDescription>
                                      Informações completas da solicitação do cliente
                                    </DialogDescription>
                                  </DialogHeader>
                                  {viewedRequest && (
                                    <div className="grid gap-4 py-4">
                                      <div className="grid gap-2">
                                        <Label className="font-semibold">Cliente</Label>
                                        <p>{viewedRequest.clientName}</p>
                                      </div>
                                      <div className="grid gap-2">
                                        <Label className="font-semibold">Contato</Label>
                                        <p>{viewedRequest.clientContact}</p>
                                      </div>
                                      <div className="grid gap-2">
                                        <Label className="font-semibold">Serviço Solicitado</Label>
                                        <p>{viewedRequest.serviceRequested}</p>
                                      </div>
                                      <div className="grid gap-2">
                                        <Label className="font-semibold">Descrição</Label>
                                        <p className="text-sm text-muted-foreground">
                                          {viewedRequest.description || "Sem descrição"}
                                        </p>
                                      </div>
                                      <div className="grid gap-2">
                                        <Label className="font-semibold">Status</Label>
                                        <Badge className="w-fit">
                                          {STATUS_LABELS[viewedRequest.status as keyof typeof STATUS_LABELS]}
                                        </Badge>
                                      </div>
                                      <div className="grid gap-2">
                                        <Label className="font-semibold">Data de Registro</Label>
                                        <p className="text-sm">{formatDate(viewedRequest.createdAt)}</p>
                                      </div>
                                    </div>
                                  )}
                                  <DialogFooter>
                                    <Button
                                      type="button"
                                      variant="outline"
                                      onClick={() => setViewingRequest(null)}
                                    >
                                      Fechar
                                    </Button>
                                    <Button
                                      type="button"
                                      onClick={() => {
                                        window.location.href = generateMailtoLink(viewedRequest);
                                      }}
                                    >
                                      <Mail className="h-4 w-4 mr-2" />
                                      Enviar Email
                                    </Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                              
                              <Dialog open={editingRequest === request.id} onOpenChange={(open) => !open && setEditingRequest(null)}>
                                <DialogTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => setEditingRequest(request.id)}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="sm:max-w-[500px]">
                                  <form onSubmit={(e) => handleUpdateRequest(e, request.id)}>
                                    <DialogHeader>
                                      <DialogTitle>Editar Solicitação</DialogTitle>
                                    </DialogHeader>
                                    <div className="grid gap-4 py-4">
                                      <div className="grid gap-2">
                                        <Label>Nome do Cliente *</Label>
                                        <Input name="clientName" defaultValue={request.clientName} required />
                                      </div>
                                      <div className="grid gap-2">
                                        <Label>Contato *</Label>
                                        <Input name="clientContact" defaultValue={request.clientContact} required />
                                      </div>
                                      <div className="grid gap-2">
                                        <Label>Serviço Solicitado *</Label>
                                        <Input name="serviceRequested" defaultValue={request.serviceRequested} required />
                                      </div>
                                      <div className="grid gap-2">
                                        <Label>Descrição</Label>
                                        <Textarea name="description" rows={3} defaultValue={request.description || ""} />
                                      </div>
                                      <div className="grid gap-2">
                                        <Label>Status</Label>
                                        <select
                                          name="status"
                                          defaultValue={request.status}
                                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                                        >
                                          <option value="pendente">Pendente</option>
                                          <option value="em_analise">Em Análise</option>
                                          <option value="agendado">Agendado</option>
                                          <option value="concluido">Concluído</option>
                                        </select>
                                      </div>
                                    </div>
                                    <DialogFooter>
                                      <Button type="button" variant="outline" onClick={() => setEditingRequest(null)}>
                                        Cancelar
                                      </Button>
                                      <Button type="submit" disabled={updateRequestMutation.isPending}>
                                        {updateRequestMutation.isPending ? "Salvando..." : "Salvar"}
                                      </Button>
                                    </DialogFooter>
                                  </form>
                                </DialogContent>
                              </Dialog>
                              
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="ghost" size="sm">
                                    <Trash2 className="h-4 w-4 text-destructive" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Tem certeza que deseja excluir a solicitação de <strong>{request.clientName}</strong>?
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => deleteRequestMutation.mutate({ id: request.id })}
                                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                    >
                                      Excluir
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="meetings" className="space-y-4">
          <div className="flex justify-end">
            <Dialog open={isCreateMeetingOpen} onOpenChange={setIsCreateMeetingOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Agendar Reunião
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <form onSubmit={handleCreateMeeting}>
                  <DialogHeader>
                    <DialogTitle>Agendar Reunião</DialogTitle>
                    <DialogDescription>
                      Preencha os dados da reunião
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                      <Label htmlFor="recruitmentRequestId">Solicitação Relacionada</Label>
                      <select
                        id="recruitmentRequestId"
                        name="recruitmentRequestId"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                      >
                        <option value="">Nenhuma</option>
                        {requests.map((request) => (
                          <option key={request.id} value={request.id}>
                            {request.clientName} - {request.serviceRequested}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="title">Título *</Label>
                      <Input id="title" name="title" required />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="meetingDate">Data e Hora *</Label>
                      <Input id="meetingDate" name="meetingDate" type="datetime-local" required />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="location">Local</Label>
                      <Input id="location" name="location" placeholder="Ex: Escritório, Online, etc" />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="description">Observações</Label>
                      <Textarea id="description" name="description" rows={2} />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setIsCreateMeetingOpen(false)}>
                      Cancelar
                    </Button>
                    <Button type="submit" disabled={createMeetingMutation.isPending}>
                      {createMeetingMutation.isPending ? "Salvando..." : "Agendar"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Reuniões Agendadas</CardTitle>
              <CardDescription>
                Total de {meetings.length} reunião{meetings.length !== 1 ? "ões" : ""} registrada{meetings.length !== 1 ? "s" : ""}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {meetings.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  Nenhuma reunião agendada ainda
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Título</TableHead>
                        <TableHead>Data/Hora</TableHead>
                        <TableHead>Local</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {meetings.map((meeting) => (
                        <TableRow key={meeting.id}>
                          <TableCell className="font-medium">{meeting.title}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4 text-muted-foreground" />
                              {formatDate(meeting.meetingDate)}
                            </div>
                          </TableCell>
                          <TableCell>{meeting.location || <span className="text-muted-foreground">-</span>}</TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                meeting.status === "realizada"
                                  ? "default"
                                  : meeting.status === "cancelada"
                                  ? "destructive"
                                  : "secondary"
                              }
                            >
                              {MEETING_STATUS_LABELS[meeting.status as keyof typeof MEETING_STATUS_LABELS]}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              <Dialog open={editingMeeting === meeting.id} onOpenChange={(open) => !open && setEditingMeeting(null)}>
                                <DialogTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => setEditingMeeting(meeting.id)}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="sm:max-w-[500px]">
                                  <form onSubmit={(e) => handleUpdateMeeting(e, meeting.id)}>
                                    <DialogHeader>
                                      <DialogTitle>Editar Reunião</DialogTitle>
                                    </DialogHeader>
                                    <div className="grid gap-4 py-4">
                                      <div className="grid gap-2">
                                        <Label>Título *</Label>
                                        <Input name="title" defaultValue={meeting.title} required />
                                      </div>
                                      <div className="grid gap-2">
                                        <Label>Data e Hora *</Label>
                                        <Input
                                          name="meetingDate"
                                          type="datetime-local"
                                          defaultValue={new Date(meeting.meetingDate).toISOString().slice(0, 16)}
                                          required
                                        />
                                      </div>
                                      <div className="grid gap-2">
                                        <Label>Local</Label>
                                        <Input name="location" defaultValue={meeting.location || ""} />
                                      </div>
                                      <div className="grid gap-2">
                                        <Label>Observações</Label>
                                        <Textarea name="description" rows={2} defaultValue={meeting.description || ""} />
                                      </div>
                                      <div className="grid gap-2">
                                        <Label>Status</Label>
                                        <select
                                          name="status"
                                          defaultValue={meeting.status}
                                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                                        >
                                          <option value="agendada">Agendada</option>
                                          <option value="realizada">Realizada</option>
                                          <option value="cancelada">Cancelada</option>
                                        </select>
                                      </div>
                                    </div>
                                    <DialogFooter>
                                      <Button type="button" variant="outline" onClick={() => setEditingMeeting(null)}>
                                        Cancelar
                                      </Button>
                                      <Button type="submit" disabled={updateMeetingMutation.isPending}>
                                        {updateMeetingMutation.isPending ? "Salvando..." : "Salvar"}
                                      </Button>
                                    </DialogFooter>
                                  </form>
                                </DialogContent>
                              </Dialog>
                              
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="ghost" size="sm">
                                    <Trash2 className="h-4 w-4 text-destructive" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Tem certeza que deseja excluir a reunião <strong>{meeting.title}</strong>?
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => deleteMeetingMutation.mutate({ id: meeting.id })}
                                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                    >
                                      Excluir
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
