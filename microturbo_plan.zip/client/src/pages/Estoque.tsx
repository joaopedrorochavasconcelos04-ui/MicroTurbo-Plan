import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Search, Edit, Trash2, Package, AlertTriangle, TrendingUp, TrendingDown, Tag } from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from "recharts";

export default function Estoque() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<number | undefined>();
  const [isCreateProductOpen, setIsCreateProductOpen] = useState(false);
  const [isCreateCategoryOpen, setIsCreateCategoryOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<number | null>(null);
  const [movementProduct, setMovementProduct] = useState<number | null>(null);
  
  const utils = trpc.useUtils();
  const { data: products = [], isLoading: loadingProducts } = trpc.products.list.useQuery({ 
    searchTerm, 
    categoryId: selectedCategory 
  });
  const { data: categories = [] } = trpc.categories.list.useQuery();
  const { data: lowStockProducts = [] } = trpc.products.lowStock.useQuery();
  
  const createProductMutation = trpc.products.create.useMutation({
    onSuccess: () => {
      utils.products.list.invalidate();
      utils.products.lowStock.invalidate();
      setIsCreateProductOpen(false);
      toast.success("Produto cadastrado com sucesso!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao cadastrar produto");
    },
  });
  
  const updateProductMutation = trpc.products.update.useMutation({
    onSuccess: () => {
      utils.products.list.invalidate();
      utils.products.lowStock.invalidate();
      setEditingProduct(null);
      toast.success("Produto atualizado com sucesso!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao atualizar produto");
    },
  });
  
  const deleteProductMutation = trpc.products.delete.useMutation({
    onSuccess: () => {
      utils.products.list.invalidate();
      utils.products.lowStock.invalidate();
      toast.success("Produto excluído com sucesso!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao excluir produto");
    },
  });

  const createCategoryMutation = trpc.categories.create.useMutation({
    onSuccess: () => {
      utils.categories.list.invalidate();
      setIsCreateCategoryOpen(false);
      toast.success("Categoria criada com sucesso!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao criar categoria");
    },
  });

  const createMovementMutation = trpc.stockMovements.create.useMutation({
    onSuccess: () => {
      utils.products.list.invalidate();
      utils.products.lowStock.invalidate();
      setMovementProduct(null);
      toast.success("Movimentação registrada com sucesso!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao registrar movimentação");
    },
  });

  const handleCreateProduct = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    createProductMutation.mutate({
      name: formData.get("name") as string,
      description: formData.get("description") as string,
      categoryId: formData.get("categoryId") ? Number(formData.get("categoryId")) : undefined,
      price: Math.round(Number(formData.get("price")) * 100), // Converter para centavos
      quantity: Number(formData.get("quantity")),
      minQuantity: Number(formData.get("minQuantity")),
    });
  };

  const handleUpdateProduct = (e: React.FormEvent<HTMLFormElement>, productId: number) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    updateProductMutation.mutate({
      id: productId,
      name: formData.get("name") as string,
      description: formData.get("description") as string,
      categoryId: formData.get("categoryId") ? Number(formData.get("categoryId")) : undefined,
      price: Math.round(Number(formData.get("price")) * 100),
      minQuantity: Number(formData.get("minQuantity")),
    });
  };

  const handleCreateCategory = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    createCategoryMutation.mutate({
      name: formData.get("name") as string,
      description: formData.get("description") as string,
    });
  };

  const handleMovement = (e: React.FormEvent<HTMLFormElement>, productId: number) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    createMovementMutation.mutate({
      productId,
      type: formData.get("type") as "entrada" | "saida",
      quantity: Number(formData.get("quantity")),
      reason: formData.get("reason") as string,
    });
  };

  const getStockStatus = (product: typeof products[0]) => {
    if (product.quantity === 0) {
      return { label: "Esgotado", variant: "destructive" as const, icon: AlertTriangle };
    }
    if (product.quantity < product.minQuantity) {
      return { label: "Repor", variant: "secondary" as const, icon: AlertTriangle };
    }
    return { label: "Ok", variant: "default" as const, icon: Package };
  };

  const formatPrice = (priceInCents: number) => {
    return (priceInCents / 100).toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Controle de Estoque</h1>
          <p className="text-muted-foreground mt-2">
            Gerencie produtos e movimentações de estoque
          </p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isCreateCategoryOpen} onOpenChange={setIsCreateCategoryOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Tag className="h-4 w-4 mr-2" />
                Nova Categoria
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[400px]">
              <form onSubmit={handleCreateCategory}>
                <DialogHeader>
                  <DialogTitle>Criar Categoria</DialogTitle>
                  <DialogDescription>
                    Adicione uma nova categoria de produtos
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="cat-name">Nome *</Label>
                    <Input id="cat-name" name="name" required />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="cat-description">Descrição</Label>
                    <Textarea id="cat-description" name="description" rows={2} />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsCreateCategoryOpen(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit" disabled={createCategoryMutation.isPending}>
                    {createCategoryMutation.isPending ? "Salvando..." : "Salvar"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
          
          <Dialog open={isCreateProductOpen} onOpenChange={setIsCreateProductOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Novo Produto
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <form onSubmit={handleCreateProduct}>
                <DialogHeader>
                  <DialogTitle>Cadastrar Produto</DialogTitle>
                  <DialogDescription>
                    Preencha os dados do novo produto
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="name">Nome *</Label>
                    <Input id="name" name="name" required />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="description">Descrição</Label>
                    <Textarea id="description" name="description" rows={2} />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="categoryId">Categoria</Label>
                    <Select name="categoryId">
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">Sem categoria</SelectItem>
                        {categories.map((cat) => (
                          <SelectItem key={cat.id} value={cat.id.toString()}>
                            {cat.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="price">Preço (R$) *</Label>
                      <Input id="price" name="price" type="number" step="0.01" min="0" required />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="quantity">Quantidade *</Label>
                      <Input id="quantity" name="quantity" type="number" min="0" defaultValue="0" required />
                    </div>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="minQuantity">Quantidade Mínima (Alerta) *</Label>
                    <Input id="minQuantity" name="minQuantity" type="number" min="0" defaultValue="5" required />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsCreateProductOpen(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit" disabled={createProductMutation.isPending}>
                    {createProductMutation.isPending ? "Salvando..." : "Salvar"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Gráfico de Produtos com Estoque Baixo */}
      {lowStockProducts.length > 0 && (
        <Card className="border-destructive/50 bg-destructive/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5" />
              Alertas de Estoque - Produtos com Estoque Baixo
            </CardTitle>
            <CardDescription>
              {lowStockProducts.length} produto{lowStockProducts.length !== 1 ? "s" : ""} com estoque abaixo de 5 unidades
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={lowStockProducts.slice(0, 10)} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={150} />
                <Tooltip 
                  formatter={(value: number) => `${value} unidade${value !== 1 ? 's' : ''}`}
                  labelStyle={{ color: "#000" }}
                />
                <Legend />
                <Bar dataKey="quantity" name="Quantidade em Estoque">
                  {lowStockProducts.slice(0, 10).map((product, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={product.quantity === 0 ? "#ef4444" : product.quantity < 5 ? "#f59e0b" : "#10b981"}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <div className="mt-4 flex items-center gap-4 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-[#ef4444]"></div>
                <span>Esgotado (0)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-[#f59e0b]"></div>
                <span>Repor (&lt; 5)</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="products" className="space-y-4">
        <TabsList>
          <TabsTrigger value="products">Produtos</TabsTrigger>
          <TabsTrigger value="categories">Categorias</TabsTrigger>
        </TabsList>

        <TabsContent value="products" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Lista de Produtos</CardTitle>
              <CardDescription>
                Total de {products.length} produto{products.length !== 1 ? "s" : ""} cadastrado{products.length !== 1 ? "s" : ""}
              </CardDescription>
              <div className="flex items-center gap-2 mt-4">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar produtos..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Select value={selectedCategory?.toString() || "all"} onValueChange={(v) => setSelectedCategory(v === "all" ? undefined : Number(v))}>
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder="Todas categorias" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas categorias</SelectItem>
                    {categories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id.toString()}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {loadingProducts ? (
                <div className="text-center py-8 text-muted-foreground">
                  Carregando produtos...
                </div>
              ) : products.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  {searchTerm || selectedCategory ? "Nenhum produto encontrado" : "Nenhum produto cadastrado ainda"}
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Produto</TableHead>
                        <TableHead>Categoria</TableHead>
                        <TableHead>Preço</TableHead>
                        <TableHead>Quantidade</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {products.map((product) => {
                        const status = getStockStatus(product);
                        const category = categories.find((c) => c.id === product.categoryId);
                        
                        return (
                          <TableRow key={product.id}>
                            <TableCell className="font-medium">
                              <div className="flex items-center gap-2">
                                <Package className="h-4 w-4 text-muted-foreground" />
                                <div>
                                  <p>{product.name}</p>
                                  {product.description && (
                                    <p className="text-sm text-muted-foreground">{product.description}</p>
                                  )}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              {category ? (
                                <Badge variant="outline">{category.name}</Badge>
                              ) : (
                                <span className="text-muted-foreground">-</span>
                              )}
                            </TableCell>
                            <TableCell className="font-medium">{formatPrice(product.price)}</TableCell>
                            <TableCell>
                              {product.quantity} un.
                            </TableCell>
                            <TableCell>
                              <Badge variant={status.variant}>
                                <status.icon className="h-3 w-3 mr-1" />
                                {status.label}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end gap-2">
                                <Dialog open={movementProduct === product.id} onOpenChange={(open) => !open && setMovementProduct(null)}>
                                  <DialogTrigger asChild>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => setMovementProduct(product.id)}
                                    >
                                      <TrendingUp className="h-4 w-4 mr-1" />
                                      Movimentar
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent className="sm:max-w-[400px]">
                                    <form onSubmit={(e) => handleMovement(e, product.id)}>
                                      <DialogHeader>
                                        <DialogTitle>Movimentar Estoque</DialogTitle>
                                        <DialogDescription>
                                          {product.name}
                                        </DialogDescription>
                                      </DialogHeader>
                                      <div className="grid gap-4 py-4">
                                        <div className="grid gap-2">
                                          <Label htmlFor={`type-${product.id}`}>Tipo *</Label>
                                          <Select name="type" required>
                                            <SelectTrigger>
                                              <SelectValue placeholder="Selecione o tipo" />
                                            </SelectTrigger>
                                            <SelectContent>
                                              <SelectItem value="entrada">Entrada</SelectItem>
                                              <SelectItem value="saida">Saída</SelectItem>
                                            </SelectContent>
                                          </Select>
                                        </div>
                                        <div className="grid gap-2">
                                          <Label htmlFor={`mov-quantity-${product.id}`}>Quantidade *</Label>
                                          <Input
                                            id={`mov-quantity-${product.id}`}
                                            name="quantity"
                                            type="number"
                                            min="1"
                                            required
                                          />
                                        </div>
                                        <div className="grid gap-2">
                                          <Label htmlFor={`reason-${product.id}`}>Motivo</Label>
                                          <Textarea
                                            id={`reason-${product.id}`}
                                            name="reason"
                                            rows={2}
                                          />
                                        </div>
                                      </div>
                                      <DialogFooter>
                                        <Button
                                          type="button"
                                          variant="outline"
                                          onClick={() => setMovementProduct(null)}
                                        >
                                          Cancelar
                                        </Button>
                                        <Button type="submit" disabled={createMovementMutation.isPending}>
                                          {createMovementMutation.isPending ? "Salvando..." : "Registrar"}
                                        </Button>
                                      </DialogFooter>
                                    </form>
                                  </DialogContent>
                                </Dialog>

                                <Dialog open={editingProduct === product.id} onOpenChange={(open) => !open && setEditingProduct(null)}>
                                  <DialogTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => setEditingProduct(product.id)}
                                    >
                                      <Edit className="h-4 w-4" />
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent className="sm:max-w-[500px]">
                                    <form onSubmit={(e) => handleUpdateProduct(e, product.id)}>
                                      <DialogHeader>
                                        <DialogTitle>Editar Produto</DialogTitle>
                                        <DialogDescription>
                                          Atualize os dados do produto
                                        </DialogDescription>
                                      </DialogHeader>
                                      <div className="grid gap-4 py-4">
                                        <div className="grid gap-2">
                                          <Label htmlFor={`edit-name-${product.id}`}>Nome *</Label>
                                          <Input
                                            id={`edit-name-${product.id}`}
                                            name="name"
                                            defaultValue={product.name}
                                            required
                                          />
                                        </div>
                                        <div className="grid gap-2">
                                          <Label htmlFor={`edit-description-${product.id}`}>Descrição</Label>
                                          <Textarea
                                            id={`edit-description-${product.id}`}
                                            name="description"
                                            rows={2}
                                            defaultValue={product.description || ""}
                                          />
                                        </div>
                                        <div className="grid gap-2">
                                          <Label htmlFor={`edit-categoryId-${product.id}`}>Categoria</Label>
                                          <Select name="categoryId" defaultValue={product.categoryId?.toString() || ""}>
                                            <SelectTrigger>
                                              <SelectValue placeholder="Selecione uma categoria" />
                                            </SelectTrigger>
                                            <SelectContent>
                                              <SelectItem value="">Sem categoria</SelectItem>
                                              {categories.map((cat) => (
                                                <SelectItem key={cat.id} value={cat.id.toString()}>
                                                  {cat.name}
                                                </SelectItem>
                                              ))}
                                            </SelectContent>
                                          </Select>
                                        </div>
                                        <div className="grid grid-cols-2 gap-4">
                                          <div className="grid gap-2">
                                            <Label htmlFor={`edit-price-${product.id}`}>Preço (R$) *</Label>
                                            <Input
                                              id={`edit-price-${product.id}`}
                                              name="price"
                                              type="number"
                                              step="0.01"
                                              min="0"
                                              defaultValue={(product.price / 100).toFixed(2)}
                                              required
                                            />
                                          </div>
                                          <div className="grid gap-2">
                                            <Label htmlFor={`edit-minQuantity-${product.id}`}>Qtd. Mínima *</Label>
                                            <Input
                                              id={`edit-minQuantity-${product.id}`}
                                              name="minQuantity"
                                              type="number"
                                              min="0"
                                              defaultValue={product.minQuantity}
                                              required
                                            />
                                          </div>
                                        </div>
                                      </div>
                                      <DialogFooter>
                                        <Button
                                          type="button"
                                          variant="outline"
                                          onClick={() => setEditingProduct(null)}
                                        >
                                          Cancelar
                                        </Button>
                                        <Button type="submit" disabled={updateProductMutation.isPending}>
                                          {updateProductMutation.isPending ? "Salvando..." : "Salvar"}
                                        </Button>
                                      </DialogFooter>
                                    </form>
                                  </DialogContent>
                                </Dialog>
                                
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button variant="ghost" size="sm">
                                      <Trash2 className="h-4 w-4 text-destructive" />
                                    </Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        Tem certeza que deseja excluir o produto <strong>{product.name}</strong>?
                                        Esta ação não pode ser desfeita.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                      <AlertDialogAction
                                        onClick={() => deleteProductMutation.mutate({ id: product.id })}
                                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                      >
                                        Excluir
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="categories">
          <Card>
            <CardHeader>
              <CardTitle>Categorias</CardTitle>
              <CardDescription>
                Total de {categories.length} categoria{categories.length !== 1 ? "s" : ""} cadastrada{categories.length !== 1 ? "s" : ""}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {categories.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  Nenhuma categoria cadastrada ainda
                </div>
              ) : (
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {categories.map((category) => {
                    const productsInCategory = products.filter((p) => p.categoryId === category.id);
                    return (
                      <Card key={category.id}>
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2 text-lg">
                            <Tag className="h-4 w-4" />
                            {category.name}
                          </CardTitle>
                          {category.description && (
                            <CardDescription>{category.description}</CardDescription>
                          )}
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground">
                            {productsInCategory.length} produto{productsInCategory.length !== 1 ? "s" : ""}
                          </p>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
