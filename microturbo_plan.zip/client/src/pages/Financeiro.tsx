import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Edit, Trash2, TrendingUp, TrendingDown, DollarSign, AlertCircle, Calendar, CheckCircle2 } from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function Financeiro() {
  const [isCreateExpenseOpen, setIsCreateExpenseOpen] = useState(false);
  const [isCreateAccountOpen, setIsCreateAccountOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<number | null>(null);
  const [editingAccount, setEditingAccount] = useState<number | null>(null);
  
  const utils = trpc.useUtils();
  const { data: expenses = [] } = trpc.expenses.list.useQuery();
  const { data: accounts = [] } = trpc.accounts.list.useQuery();
  const { data: stats } = trpc.financial.stats.useQuery();
  
  const createExpenseMutation = trpc.expenses.create.useMutation({
    onSuccess: () => {
      utils.expenses.list.invalidate();
      utils.financial.stats.invalidate();
      setIsCreateExpenseOpen(false);
      toast.success("Despesa registrada com sucesso!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao registrar despesa");
    },
  });
  
  const updateExpenseMutation = trpc.expenses.update.useMutation({
    onSuccess: () => {
      utils.expenses.list.invalidate();
      utils.financial.stats.invalidate();
      setEditingExpense(null);
      toast.success("Despesa atualizada com sucesso!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao atualizar despesa");
    },
  });
  
  const deleteExpenseMutation = trpc.expenses.delete.useMutation({
    onSuccess: () => {
      utils.expenses.list.invalidate();
      utils.financial.stats.invalidate();
      toast.success("Despesa excluída com sucesso!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao excluir despesa");
    },
  });

  const createAccountMutation = trpc.accounts.create.useMutation({
    onSuccess: () => {
      utils.accounts.list.invalidate();
      utils.financial.stats.invalidate();
      setIsCreateAccountOpen(false);
      toast.success("Conta registrada com sucesso!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao registrar conta");
    },
  });
  
  const updateAccountMutation = trpc.accounts.update.useMutation({
    onSuccess: () => {
      utils.accounts.list.invalidate();
      utils.financial.stats.invalidate();
      setEditingAccount(null);
      toast.success("Conta atualizada com sucesso!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao atualizar conta");
    },
  });
  
  const deleteAccountMutation = trpc.accounts.delete.useMutation({
    onSuccess: () => {
      utils.accounts.list.invalidate();
      utils.financial.stats.invalidate();
      toast.success("Conta excluída com sucesso!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao excluir conta");
    },
  });

  const handleCreateExpense = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    createExpenseMutation.mutate({
      name: formData.get("name") as string,
      amount: Math.round(Number(formData.get("amount")) * 100),
      category: formData.get("category") as string,
      expenseDate: new Date(formData.get("expenseDate") as string),
      description: formData.get("description") as string,
    });
  };

  const handleUpdateExpense = (e: React.FormEvent<HTMLFormElement>, expenseId: number) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    updateExpenseMutation.mutate({
      id: expenseId,
      name: formData.get("name") as string,
      amount: Math.round(Number(formData.get("amount")) * 100),
      category: formData.get("category") as string,
      expenseDate: new Date(formData.get("expenseDate") as string),
      description: formData.get("description") as string,
    });
  };

  const handleCreateAccount = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    createAccountMutation.mutate({
      type: formData.get("type") as "pagar" | "receber",
      description: formData.get("description") as string,
      amount: Math.round(Number(formData.get("amount")) * 100),
      dueDate: new Date(formData.get("dueDate") as string),
      isPaid: formData.get("isPaid") === "on",
      paidDate: formData.get("isPaid") === "on" ? new Date() : undefined,
    });
  };

  const handleUpdateAccount = (e: React.FormEvent<HTMLFormElement>, accountId: number) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    updateAccountMutation.mutate({
      id: accountId,
      type: formData.get("type") as "pagar" | "receber",
      description: formData.get("description") as string,
      amount: Math.round(Number(formData.get("amount")) * 100),
      dueDate: new Date(formData.get("dueDate") as string),
      isPaid: formData.get("isPaid") === "on",
    });
  };

  const toggleAccountPaid = (accountId: number, currentStatus: boolean) => {
    updateAccountMutation.mutate({
      id: accountId,
      isPaid: !currentStatus,
      paidDate: !currentStatus ? new Date() : undefined,
    });
  };

  const formatPrice = (priceInCents: number) => {
    return (priceInCents / 100).toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
    });
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("pt-BR");
  };

  const isOverdue = (dueDate: Date, isPaid: boolean) => {
    if (isPaid) return false;
    return new Date(dueDate) < new Date();
  };

  const isDueSoon = (dueDate: Date, isPaid: boolean) => {
    if (isPaid) return false;
    const today = new Date();
    const due = new Date(dueDate);
    const diffDays = Math.ceil((due.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return diffDays >= 0 && diffDays <= 7;
  };

  const accountsToPay = accounts.filter(a => a.type === "pagar");
  const accountsToReceive = accounts.filter(a => a.type === "receber");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Controle Financeiro</h1>
        <p className="text-muted-foreground mt-2">
          Acompanhe vendas, despesas e contas a pagar/receber
        </p>
      </div>

      {/* Statistics Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{formatPrice(stats?.totalRevenue || 0)}</div>
            <p className="text-xs text-muted-foreground">vendas registradas</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Despesas</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{formatPrice(stats?.totalExpenses || 0)}</div>
            <p className="text-xs text-muted-foreground">em despesas</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Lucro</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${(stats?.profit || 0) >= 0 ? "text-green-600" : "text-red-600"}`}>
              {formatPrice(stats?.profit || 0)}
            </div>
            <p className="text-xs text-muted-foreground">receita - despesas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">A Receber</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{formatPrice(stats?.pendingReceivables || 0)}</div>
            <p className="text-xs text-muted-foreground">pendentes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">A Pagar</CardTitle>
            <TrendingDown className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{formatPrice(stats?.pendingPayables || 0)}</div>
            <p className="text-xs text-muted-foreground">pendentes</p>
          </CardContent>
        </Card>
      </div>

      {/* Gráfico de Receitas x Despesas por Mês */}
      <Card>
        <CardHeader>
          <CardTitle>Receitas x Despesas por Mês</CardTitle>
          <CardDescription>Comparativo dos últimos 6 meses</CardDescription>
        </CardHeader>
        <CardContent>
          {(() => {
            // Combinar dados de receitas e despesas por mês
            const monthsMap = new Map<string, { month: string; monthLabel: string; receita: number; despesa: number }>();
            
            // Adicionar receitas
            (stats?.revenueByMonth || []).forEach((item: any) => {
              monthsMap.set(item.month, {
                month: item.month,
                monthLabel: item.monthLabel,
                receita: Number(item.total) / 100,
                despesa: 0,
              });
            });
            
            // Adicionar despesas
            (stats?.expensesByMonth || []).forEach((item: any) => {
              const existing = monthsMap.get(item.month);
              if (existing) {
                existing.despesa = Number(item.total) / 100;
              } else {
                monthsMap.set(item.month, {
                  month: item.month,
                  monthLabel: item.monthLabel,
                  receita: 0,
                  despesa: Number(item.total) / 100,
                });
              }
            });
            
            const chartData = Array.from(monthsMap.values()).sort((a, b) => a.month.localeCompare(b.month));
            
            return chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="monthLabel" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value: number) => new Intl.NumberFormat("pt-BR", {
                      style: "currency",
                      currency: "BRL",
                    }).format(value)}
                    labelStyle={{ color: "#000" }}
                  />
                  <Legend />
                  <Bar dataKey="receita" fill="#10b981" name="Receitas" />
                  <Bar dataKey="despesa" fill="#ef4444" name="Despesas" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                Nenhum dado financeiro registrado nos últimos 6 meses
              </div>
            );
          })()}
        </CardContent>
      </Card>

      <Tabs defaultValue="expenses" className="space-y-4">
        <TabsList>
          <TabsTrigger value="expenses">Despesas</TabsTrigger>
          <TabsTrigger value="accounts">Contas a Pagar/Receber</TabsTrigger>
        </TabsList>

        <TabsContent value="expenses" className="space-y-4">
          <div className="flex justify-end">
            <Dialog open={isCreateExpenseOpen} onOpenChange={setIsCreateExpenseOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Nova Despesa
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <form onSubmit={handleCreateExpense}>
                  <DialogHeader>
                    <DialogTitle>Registrar Despesa</DialogTitle>
                    <DialogDescription>
                      Preencha os dados da nova despesa
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                      <Label htmlFor="name">Nome *</Label>
                      <Input id="name" name="name" required />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="amount">Valor (R$) *</Label>
                        <Input id="amount" name="amount" type="number" step="0.01" min="0" required />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="category">Categoria</Label>
                        <Input id="category" name="category" placeholder="Ex: Aluguel, Salários" />
                      </div>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="expenseDate">Data *</Label>
                      <Input
                        id="expenseDate"
                        name="expenseDate"
                        type="date"
                        defaultValue={new Date().toISOString().split('T')[0]}
                        required
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="description">Descrição</Label>
                      <Textarea id="description" name="description" rows={2} />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setIsCreateExpenseOpen(false)}>
                      Cancelar
                    </Button>
                    <Button type="submit" disabled={createExpenseMutation.isPending}>
                      {createExpenseMutation.isPending ? "Salvando..." : "Salvar"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Despesas Registradas</CardTitle>
              <CardDescription>
                Total de {expenses.length} despesa{expenses.length !== 1 ? "s" : ""}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {expenses.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  Nenhuma despesa registrada ainda
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nome</TableHead>
                        <TableHead>Categoria</TableHead>
                        <TableHead>Data</TableHead>
                        <TableHead>Valor</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {expenses.map((expense) => (
                        <TableRow key={expense.id}>
                          <TableCell className="font-medium">{expense.name}</TableCell>
                          <TableCell>
                            {expense.category ? (
                              <Badge variant="outline">{expense.category}</Badge>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                          <TableCell>{formatDate(expense.expenseDate)}</TableCell>
                          <TableCell className="font-semibold text-red-600">{formatPrice(expense.amount)}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              <Dialog open={editingExpense === expense.id} onOpenChange={(open) => !open && setEditingExpense(null)}>
                                <DialogTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => setEditingExpense(expense.id)}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="sm:max-w-[500px]">
                                  <form onSubmit={(e) => handleUpdateExpense(e, expense.id)}>
                                    <DialogHeader>
                                      <DialogTitle>Editar Despesa</DialogTitle>
                                      <DialogDescription>
                                        Atualize os dados da despesa
                                      </DialogDescription>
                                    </DialogHeader>
                                    <div className="grid gap-4 py-4">
                                      <div className="grid gap-2">
                                        <Label htmlFor={`edit-name-${expense.id}`}>Nome *</Label>
                                        <Input
                                          id={`edit-name-${expense.id}`}
                                          name="name"
                                          defaultValue={expense.name}
                                          required
                                        />
                                      </div>
                                      <div className="grid grid-cols-2 gap-4">
                                        <div className="grid gap-2">
                                          <Label htmlFor={`edit-amount-${expense.id}`}>Valor (R$) *</Label>
                                          <Input
                                            id={`edit-amount-${expense.id}`}
                                            name="amount"
                                            type="number"
                                            step="0.01"
                                            min="0"
                                            defaultValue={(expense.amount / 100).toFixed(2)}
                                            required
                                          />
                                        </div>
                                        <div className="grid gap-2">
                                          <Label htmlFor={`edit-category-${expense.id}`}>Categoria</Label>
                                          <Input
                                            id={`edit-category-${expense.id}`}
                                            name="category"
                                            defaultValue={expense.category || ""}
                                          />
                                        </div>
                                      </div>
                                      <div className="grid gap-2">
                                        <Label htmlFor={`edit-expenseDate-${expense.id}`}>Data *</Label>
                                        <Input
                                          id={`edit-expenseDate-${expense.id}`}
                                          name="expenseDate"
                                          type="date"
                                          defaultValue={new Date(expense.expenseDate).toISOString().split('T')[0]}
                                          required
                                        />
                                      </div>
                                      <div className="grid gap-2">
                                        <Label htmlFor={`edit-description-${expense.id}`}>Descrição</Label>
                                        <Textarea
                                          id={`edit-description-${expense.id}`}
                                          name="description"
                                          rows={2}
                                          defaultValue={expense.description || ""}
                                        />
                                      </div>
                                    </div>
                                    <DialogFooter>
                                      <Button
                                        type="button"
                                        variant="outline"
                                        onClick={() => setEditingExpense(null)}
                                      >
                                        Cancelar
                                      </Button>
                                      <Button type="submit" disabled={updateExpenseMutation.isPending}>
                                        {updateExpenseMutation.isPending ? "Salvando..." : "Salvar"}
                                      </Button>
                                    </DialogFooter>
                                  </form>
                                </DialogContent>
                              </Dialog>
                              
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="ghost" size="sm">
                                    <Trash2 className="h-4 w-4 text-destructive" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Tem certeza que deseja excluir a despesa <strong>{expense.name}</strong>?
                                      Esta ação não pode ser desfeita.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => deleteExpenseMutation.mutate({ id: expense.id })}
                                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                    >
                                      Excluir
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="accounts" className="space-y-4">
          <div className="flex justify-end">
            <Dialog open={isCreateAccountOpen} onOpenChange={setIsCreateAccountOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Nova Conta
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <form onSubmit={handleCreateAccount}>
                  <DialogHeader>
                    <DialogTitle>Registrar Conta</DialogTitle>
                    <DialogDescription>
                      Preencha os dados da nova conta a pagar ou receber
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                      <Label htmlFor="type">Tipo *</Label>
                      <select
                        id="type"
                        name="type"
                        required
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      >
                        <option value="pagar">A Pagar</option>
                        <option value="receber">A Receber</option>
                      </select>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="description">Descrição *</Label>
                      <Input id="description" name="description" required />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="amount">Valor (R$) *</Label>
                        <Input id="amount" name="amount" type="number" step="0.01" min="0" required />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="dueDate">Vencimento *</Label>
                        <Input id="dueDate" name="dueDate" type="date" required />
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="isPaid" name="isPaid" />
                      <Label htmlFor="isPaid" className="font-normal cursor-pointer">
                        Já está pago/recebido
                      </Label>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setIsCreateAccountOpen(false)}>
                      Cancelar
                    </Button>
                    <Button type="submit" disabled={createAccountMutation.isPending}>
                      {createAccountMutation.isPending ? "Salvando..." : "Salvar"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5 text-orange-600" />
                  Contas a Pagar
                </CardTitle>
                <CardDescription>
                  {accountsToPay.filter(a => !a.isPaid).length} pendente{accountsToPay.filter(a => !a.isPaid).length !== 1 ? "s" : ""}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {accountsToPay.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    Nenhuma conta a pagar
                  </div>
                ) : (
                  <div className="space-y-3">
                    {accountsToPay.map((account) => (
                      <div
                        key={account.id}
                        className={`p-3 rounded-lg border ${
                          account.isPaid
                            ? "bg-muted/30"
                            : isOverdue(account.dueDate, account.isPaid)
                            ? "border-red-500 bg-red-50"
                            : isDueSoon(account.dueDate, account.isPaid)
                            ? "border-orange-500 bg-orange-50"
                            : ""
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <Checkbox
                                checked={account.isPaid}
                                onCheckedChange={() => toggleAccountPaid(account.id, account.isPaid)}
                              />
                              <p className={`font-medium ${account.isPaid ? "line-through text-muted-foreground" : ""}`}>
                                {account.description}
                              </p>
                            </div>
                            <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <Calendar className="h-3 w-3" />
                                {formatDate(account.dueDate)}
                              </span>
                              <span className="font-semibold text-orange-600">{formatPrice(account.amount)}</span>
                            </div>
                            {isOverdue(account.dueDate, account.isPaid) && (
                              <Badge variant="destructive" className="mt-2">
                                <AlertCircle className="h-3 w-3 mr-1" />
                                Vencida
                              </Badge>
                            )}
                            {isDueSoon(account.dueDate, account.isPaid) && (
                              <Badge className="mt-2 bg-orange-500">
                                <AlertCircle className="h-3 w-3 mr-1" />
                                Vence em breve
                              </Badge>
                            )}
                            {account.isPaid && account.paidDate && (
                              <Badge variant="secondary" className="mt-2">
                                <CheckCircle2 className="h-3 w-3 mr-1" />
                                Pago em {formatDate(account.paidDate)}
                              </Badge>
                            )}
                          </div>
                          <div className="flex gap-1">
                            <Dialog open={editingAccount === account.id} onOpenChange={(open) => !open && setEditingAccount(null)}>
                              <DialogTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => setEditingAccount(account.id)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="sm:max-w-[500px]">
                                <form onSubmit={(e) => handleUpdateAccount(e, account.id)}>
                                  <DialogHeader>
                                    <DialogTitle>Editar Conta</DialogTitle>
                                  </DialogHeader>
                                  <div className="grid gap-4 py-4">
                                    <div className="grid gap-2">
                                      <Label>Tipo *</Label>
                                      <select
                                        name="type"
                                        defaultValue={account.type}
                                        required
                                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                                      >
                                        <option value="pagar">A Pagar</option>
                                        <option value="receber">A Receber</option>
                                      </select>
                                    </div>
                                    <div className="grid gap-2">
                                      <Label>Descrição *</Label>
                                      <Input name="description" defaultValue={account.description} required />
                                    </div>
                                    <div className="grid grid-cols-2 gap-4">
                                      <div className="grid gap-2">
                                        <Label>Valor (R$) *</Label>
                                        <Input
                                          name="amount"
                                          type="number"
                                          step="0.01"
                                          min="0"
                                          defaultValue={(account.amount / 100).toFixed(2)}
                                          required
                                        />
                                      </div>
                                      <div className="grid gap-2">
                                        <Label>Vencimento *</Label>
                                        <Input
                                          name="dueDate"
                                          type="date"
                                          defaultValue={new Date(account.dueDate).toISOString().split('T')[0]}
                                          required
                                        />
                                      </div>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                      <Checkbox name="isPaid" defaultChecked={account.isPaid} />
                                      <Label className="font-normal">Já está pago/recebido</Label>
                                    </div>
                                  </div>
                                  <DialogFooter>
                                    <Button type="button" variant="outline" onClick={() => setEditingAccount(null)}>
                                      Cancelar
                                    </Button>
                                    <Button type="submit" disabled={updateAccountMutation.isPending}>
                                      {updateAccountMutation.isPending ? "Salvando..." : "Salvar"}
                                    </Button>
                                  </DialogFooter>
                                </form>
                              </DialogContent>
                            </Dialog>
                            
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="ghost" size="sm">
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Tem certeza que deseja excluir esta conta?
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => deleteAccountMutation.mutate({ id: account.id })}
                                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                  >
                                    Excluir
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-blue-600" />
                  Contas a Receber
                </CardTitle>
                <CardDescription>
                  {accountsToReceive.filter(a => !a.isPaid).length} pendente{accountsToReceive.filter(a => !a.isPaid).length !== 1 ? "s" : ""}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {accountsToReceive.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    Nenhuma conta a receber
                  </div>
                ) : (
                  <div className="space-y-3">
                    {accountsToReceive.map((account) => (
                      <div
                        key={account.id}
                        className={`p-3 rounded-lg border ${
                          account.isPaid
                            ? "bg-muted/30"
                            : isOverdue(account.dueDate, account.isPaid)
                            ? "border-red-500 bg-red-50"
                            : isDueSoon(account.dueDate, account.isPaid)
                            ? "border-blue-500 bg-blue-50"
                            : ""
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <Checkbox
                                checked={account.isPaid}
                                onCheckedChange={() => toggleAccountPaid(account.id, account.isPaid)}
                              />
                              <p className={`font-medium ${account.isPaid ? "line-through text-muted-foreground" : ""}`}>
                                {account.description}
                              </p>
                            </div>
                            <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <Calendar className="h-3 w-3" />
                                {formatDate(account.dueDate)}
                              </span>
                              <span className="font-semibold text-blue-600">{formatPrice(account.amount)}</span>
                            </div>
                            {isOverdue(account.dueDate, account.isPaid) && (
                              <Badge variant="destructive" className="mt-2">
                                <AlertCircle className="h-3 w-3 mr-1" />
                                Vencida
                              </Badge>
                            )}
                            {isDueSoon(account.dueDate, account.isPaid) && (
                              <Badge className="mt-2 bg-blue-500">
                                <AlertCircle className="h-3 w-3 mr-1" />
                                Vence em breve
                              </Badge>
                            )}
                            {account.isPaid && account.paidDate && (
                              <Badge variant="secondary" className="mt-2">
                                <CheckCircle2 className="h-3 w-3 mr-1" />
                                Recebido em {formatDate(account.paidDate)}
                              </Badge>
                            )}
                          </div>
                          <div className="flex gap-1">
                            <Dialog open={editingAccount === account.id} onOpenChange={(open) => !open && setEditingAccount(null)}>
                              <DialogTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => setEditingAccount(account.id)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="sm:max-w-[500px]">
                                <form onSubmit={(e) => handleUpdateAccount(e, account.id)}>
                                  <DialogHeader>
                                    <DialogTitle>Editar Conta</DialogTitle>
                                  </DialogHeader>
                                  <div className="grid gap-4 py-4">
                                    <div className="grid gap-2">
                                      <Label>Tipo *</Label>
                                      <select
                                        name="type"
                                        defaultValue={account.type}
                                        required
                                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                                      >
                                        <option value="pagar">A Pagar</option>
                                        <option value="receber">A Receber</option>
                                      </select>
                                    </div>
                                    <div className="grid gap-2">
                                      <Label>Descrição *</Label>
                                      <Input name="description" defaultValue={account.description} required />
                                    </div>
                                    <div className="grid grid-cols-2 gap-4">
                                      <div className="grid gap-2">
                                        <Label>Valor (R$) *</Label>
                                        <Input
                                          name="amount"
                                          type="number"
                                          step="0.01"
                                          min="0"
                                          defaultValue={(account.amount / 100).toFixed(2)}
                                          required
                                        />
                                      </div>
                                      <div className="grid gap-2">
                                        <Label>Vencimento *</Label>
                                        <Input
                                          name="dueDate"
                                          type="date"
                                          defaultValue={new Date(account.dueDate).toISOString().split('T')[0]}
                                          required
                                        />
                                      </div>
                                    </div>
                                    <div className="flex items-center space-x-2">
                                      <Checkbox name="isPaid" defaultChecked={account.isPaid} />
                                      <Label className="font-normal">Já está pago/recebido</Label>
                                    </div>
                                  </div>
                                  <DialogFooter>
                                    <Button type="button" variant="outline" onClick={() => setEditingAccount(null)}>
                                      Cancelar
                                    </Button>
                                    <Button type="submit" disabled={updateAccountMutation.isPending}>
                                      {updateAccountMutation.isPending ? "Salvando..." : "Salvar"}
                                    </Button>
                                  </DialogFooter>
                                </form>
                              </DialogContent>
                            </Dialog>
                            
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="ghost" size="sm">
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Tem certeza que deseja excluir esta conta?
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => deleteAccountMutation.mutate({ id: account.id })}
                                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                  >
                                    Excluir
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
