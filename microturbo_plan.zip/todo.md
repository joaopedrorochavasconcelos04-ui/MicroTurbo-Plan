# MicroTurbo Plan - Lista de Tarefas

## Infraestrutura e Layout
- [x] Configurar schema do banco de dados com todas as tabelas necessárias
- [x] Implementar layout principal com navegação lateral (DashboardLayout)
- [x] Configurar tema visual moderno e limpo
- [x] Implementar sistema de autenticação simples

## 1. Gestão de Clientes
- [x] Criar tabela de clientes no banco de dados
- [x] Implementar página de listagem de clientes
- [x] Implementar formulário de cadastro de clientes
- [x] Implementar edição de clientes
- [x] Implementar exclusão de clientes
- [x] Adicionar campo de observações e "cliente fiel"
- [x] Integrar histórico de compras do cliente

## 2. Controle de Estoque
- [x] Criar tabela de produtos no banco de dados
- [x] Criar tabela de movimentações de estoque
- [x] Implementar página de listagem de produtos
- [x] Implementar cadastro de produtos com categorias
- [x] Implementar controle de entrada e saída de estoque
- [x] Adicionar alertas de estoque baixo (quantidade < 5)
- [x] Implementar status automático (Esgotado/Repor/Ok)
- [x] Adicionar filtros por categoria
- [x] Criar relatório de estoque

## 3. Painel de Vendas
- [x] Criar tabela de vendas no banco de dados
- [x] Criar tabela de itens de venda
- [x] Implementar página de registro de vendas
- [x] Adicionar campos: data, hora, produtos, quantidade, preço, total, forma de pagamento
- [x] Implementar histórico completo de vendas
- [x] Adicionar filtros (data, cliente, produto, forma de pagamento)
- [x] Implementar edição de vendas
- [x] Implementar exclusão de vendas
- [x] Criar gráficos de vendas (dia/semana/mês)
- [x] Implementar ranking de produtos mais vendidos
- [x] Criar resumo por forma de pagamento

## 4. Controle Financeiro
- [x] Criar tabela de despesas
- [x] Criar tabela de contas a pagar/receber
- [x] Implementar registro de despesas (nome, valor, data, categoria)
- [x] Implementar contas a pagar
- [x] Implementar contas a receber
- [x] Adicionar alertas de vencimento próximo
- [x] Criar relatório de vendas vs despesas
- [x] Implementar cálculo de lucro simples
- [x] Integrar com módulo de vendas

## 5. Módulo de Recrutamento
- [x] Criar tabela de solicitações de clientes
- [x] Criar tabela de reuniões agendadas
- [x] Implementar página de solicitações
- [x] Criar modal de visualização de solicitação
- [x] Adicionar botão de gerar email (mailto:) para marcar reunião
- [x] Implementar listagem de reuniões agendadas
- [x] Implementar exclusão de solicitações

## 6. Dashboard Principal
- [x] Criar página do dashboard
- [x] Implementar gráficos de vendas
- [x] Implementar gráficos de despesas
- [x] Implementar gráfico de lucro
- [x] Mostrar total de clientes, produtos e vendas
- [x] Listar últimas vendas
- [x] Adicionar alertas de produtos com estoque baixo
- [x] Adicionar alertas de contas a vencer
- [x] Adicionar alertas de novas solicitações de recrutamento

## Testes e Finalização
- [x] Criar testes básicos para os principais módulos
- [x] Validar formulários
- [x] Testar todos os CRUDs
- [x] Verificar responsividade
- [x] Criar checkpoint final

## Correções de Bugs
- [x] Corrigir erro de removeChild ao abrir/fechar modais

## Melhorias de Gráficos e Visualizações
- [x] Adicionar gráfico de barras de vendas por semana/mês
- [x] Melhorar ranking de produtos mais vendidos (top 5)
- [x] Adicionar gráfico de receitas x despesas por mês
- [x] Criar visualização de produtos com estoque baixo
- [x] Melhorar cards de resumo financeiro no dashboard

## Dados de Demonstração
- [x] Criar script para popular banco com dados realistas
- [x] Adicionar 20-30 produtos variados com categorias
- [x] Adicionar 10-15 clientes
- [x] Gerar 50+ vendas distribuídas nos últimos 3 meses
- [x] Adicionar despesas variadas
- [x] Criar contas a pagar e receber
- [x] Adicionar solicitações de recrutamento
