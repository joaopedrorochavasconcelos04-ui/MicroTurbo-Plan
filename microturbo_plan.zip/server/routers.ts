import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  customers: router({
    list: protectedProcedure
      .input(z.object({
        searchTerm: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getAllCustomers(input?.searchTerm);
      }),
    
    getById: protectedProcedure
      .input(z.object({
        id: z.number(),
      }))
      .query(async ({ input }) => {
        return await db.getCustomerById(input.id);
      }),
    
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1, "Nome é obrigatório"),
        phone: z.string().optional(),
        email: z.string().email("Email inválido").optional().or(z.literal("")),
        observations: z.string().optional(),
        isFrequentBuyer: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createCustomer({
          name: input.name,
          phone: input.phone || null,
          email: input.email || null,
          observations: input.observations || null,
          isFrequentBuyer: input.isFrequentBuyer || false,
        });
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1, "Nome é obrigatório").optional(),
        phone: z.string().optional(),
        email: z.string().email("Email inválido").optional().or(z.literal("")),
        observations: z.string().optional(),
        isFrequentBuyer: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        const updateData: any = {};
        
        if (data.name !== undefined) updateData.name = data.name;
        if (data.phone !== undefined) updateData.phone = data.phone || null;
        if (data.email !== undefined) updateData.email = data.email || null;
        if (data.observations !== undefined) updateData.observations = data.observations || null;
        if (data.isFrequentBuyer !== undefined) updateData.isFrequentBuyer = data.isFrequentBuyer;
        
        return await db.updateCustomer(id, updateData);
      }),
    
    delete: protectedProcedure
      .input(z.object({
        id: z.number(),
      }))
      .mutation(async ({ input }) => {
        await db.deleteCustomer(input.id);
        return { success: true };
      }),
  }),

  categories: router({
    list: protectedProcedure.query(async () => {
      return await db.getAllCategories();
    }),
    
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1, "Nome é obrigatório"),
        description: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createCategory({
          name: input.name,
          description: input.description || null,
        });
      }),
  }),

  products: router({
    list: protectedProcedure
      .input(z.object({
        searchTerm: z.string().optional(),
        categoryId: z.number().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getAllProducts(input?.searchTerm, input?.categoryId);
      }),
    
    lowStock: protectedProcedure.query(async () => {
      return await db.getLowStockProducts();
    }),
    
    getById: protectedProcedure
      .input(z.object({
        id: z.number(),
      }))
      .query(async ({ input }) => {
        return await db.getProductById(input.id);
      }),
    
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1, "Nome é obrigatório"),
        description: z.string().optional(),
        categoryId: z.number().optional(),
        price: z.number().min(0, "Preço deve ser maior ou igual a zero"),
        quantity: z.number().min(0, "Quantidade deve ser maior ou igual a zero").default(0),
        minQuantity: z.number().min(0, "Quantidade mínima deve ser maior ou igual a zero").default(5),
      }))
      .mutation(async ({ input }) => {
        return await db.createProduct({
          name: input.name,
          description: input.description || null,
          categoryId: input.categoryId || null,
          price: input.price,
          quantity: input.quantity,
          minQuantity: input.minQuantity,
        });
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1, "Nome é obrigatório").optional(),
        description: z.string().optional(),
        categoryId: z.number().optional(),
        price: z.number().min(0, "Preço deve ser maior ou igual a zero").optional(),
        quantity: z.number().min(0, "Quantidade deve ser maior ou igual a zero").optional(),
        minQuantity: z.number().min(0, "Quantidade mínima deve ser maior ou igual a zero").optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        const updateData: any = {};
        
        if (data.name !== undefined) updateData.name = data.name;
        if (data.description !== undefined) updateData.description = data.description || null;
        if (data.categoryId !== undefined) updateData.categoryId = data.categoryId || null;
        if (data.price !== undefined) updateData.price = data.price;
        if (data.quantity !== undefined) updateData.quantity = data.quantity;
        if (data.minQuantity !== undefined) updateData.minQuantity = data.minQuantity;
        
        return await db.updateProduct(id, updateData);
      }),
    
    delete: protectedProcedure
      .input(z.object({
        id: z.number(),
      }))
      .mutation(async ({ input }) => {
        await db.deleteProduct(input.id);
        return { success: true };
      }),
  }),

  stockMovements: router({
    listByProduct: protectedProcedure
      .input(z.object({
        productId: z.number(),
      }))
      .query(async ({ input }) => {
        return await db.getStockMovementsByProduct(input.productId);
      }),
    
    create: protectedProcedure
      .input(z.object({
        productId: z.number(),
        type: z.enum(["entrada", "saida"]),
        quantity: z.number().min(1, "Quantidade deve ser maior que zero"),
        reason: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createStockMovement({
          productId: input.productId,
          type: input.type,
          quantity: input.quantity,
          reason: input.reason || null,
          createdBy: ctx.user.id,
        });
      }),
  }),

  sales: router({
    list: protectedProcedure
      .input(z.object({
        startDate: z.date().optional(),
        endDate: z.date().optional(),
        customerId: z.number().optional(),
        paymentMethod: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getAllSales(input);
      }),
    
    getById: protectedProcedure
      .input(z.object({
        id: z.number(),
      }))
      .query(async ({ input }) => {
        const sale = await db.getSaleById(input.id);
        if (!sale) return null;
        
        const items = await db.getSaleItems(input.id);
        return { ...sale, items };
      }),
    
    create: protectedProcedure
      .input(z.object({
        customerId: z.number().optional(),
        customerName: z.string().optional(),
        saleDate: z.date(),
        paymentMethod: z.enum(["dinheiro", "cartao_credito", "cartao_debito", "pix", "transferencia"]),
        observations: z.string().optional(),
        items: z.array(z.object({
          productId: z.number().optional(),
          productName: z.string(),
          quantity: z.number().min(1),
          unitPrice: z.number().min(0),
        })),
      }))
      .mutation(async ({ input, ctx }) => {
        const total = input.items.reduce((sum, item) => sum + (item.unitPrice * item.quantity), 0);
        
        return await db.createSale(
          {
            customerId: input.customerId || null,
            customerName: input.customerName || null,
            total,
            paymentMethod: input.paymentMethod,
            observations: input.observations || null,
            saleDate: input.saleDate,
            createdBy: ctx.user.id,
          },
          input.items.map(item => ({
            productId: item.productId || null,
            productName: item.productName,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            subtotal: item.unitPrice * item.quantity,
          }))
        );
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        customerId: z.number().optional(),
        customerName: z.string().optional(),
        paymentMethod: z.enum(["dinheiro", "cartao_credito", "cartao_debito", "pix", "transferencia"]).optional(),
        observations: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        const updateData: any = {};
        
        if (data.customerId !== undefined) updateData.customerId = data.customerId || null;
        if (data.customerName !== undefined) updateData.customerName = data.customerName || null;
        if (data.paymentMethod !== undefined) updateData.paymentMethod = data.paymentMethod;
        if (data.observations !== undefined) updateData.observations = data.observations || null;
        
        return await db.updateSale(id, updateData);
      }),
    
    delete: protectedProcedure
      .input(z.object({
        id: z.number(),
      }))
      .mutation(async ({ input }) => {
        await db.deleteSale(input.id);
        return { success: true };
      }),
    
    stats: protectedProcedure
      .input(z.object({
        startDate: z.date().optional(),
        endDate: z.date().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getSalesStats(input?.startDate, input?.endDate);
      }),
  }),

  expenses: router({
    list: protectedProcedure
      .input(z.object({
        startDate: z.date().optional(),
        endDate: z.date().optional(),
        category: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getAllExpenses(input);
      }),
    
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1, "Nome é obrigatório"),
        amount: z.number().min(0, "Valor deve ser maior ou igual a zero"),
        category: z.string().optional(),
        expenseDate: z.date(),
        description: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createExpense({
          name: input.name,
          amount: input.amount,
          category: input.category || null,
          expenseDate: input.expenseDate,
          description: input.description || null,
          createdBy: ctx.user.id,
        });
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1, "Nome é obrigatório").optional(),
        amount: z.number().min(0, "Valor deve ser maior ou igual a zero").optional(),
        category: z.string().optional(),
        expenseDate: z.date().optional(),
        description: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        const updateData: any = {};
        
        if (data.name !== undefined) updateData.name = data.name;
        if (data.amount !== undefined) updateData.amount = data.amount;
        if (data.category !== undefined) updateData.category = data.category || null;
        if (data.expenseDate !== undefined) updateData.expenseDate = data.expenseDate;
        if (data.description !== undefined) updateData.description = data.description || null;
        
        return await db.updateExpense(id, updateData);
      }),
    
    delete: protectedProcedure
      .input(z.object({
        id: z.number(),
      }))
      .mutation(async ({ input }) => {
        await db.deleteExpense(input.id);
        return { success: true };
      }),
  }),

  accounts: router({
    list: protectedProcedure
      .input(z.object({
        type: z.enum(["pagar", "receber"]).optional(),
        isPaid: z.boolean().optional(),
        dueSoon: z.boolean().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getAllAccounts(input);
      }),
    
    create: protectedProcedure
      .input(z.object({
        type: z.enum(["pagar", "receber"]),
        description: z.string().min(1, "Descrição é obrigatória"),
        amount: z.number().min(0, "Valor deve ser maior ou igual a zero"),
        dueDate: z.date(),
        isPaid: z.boolean().optional(),
        paidDate: z.date().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createAccount({
          type: input.type,
          description: input.description,
          amount: input.amount,
          dueDate: input.dueDate,
          isPaid: input.isPaid || false,
          paidDate: input.paidDate || null,
          createdBy: ctx.user.id,
        });
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        type: z.enum(["pagar", "receber"]).optional(),
        description: z.string().min(1, "Descrição é obrigatória").optional(),
        amount: z.number().min(0, "Valor deve ser maior ou igual a zero").optional(),
        dueDate: z.date().optional(),
        isPaid: z.boolean().optional(),
        paidDate: z.date().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        const updateData: any = {};
        
        if (data.type !== undefined) updateData.type = data.type;
        if (data.description !== undefined) updateData.description = data.description;
        if (data.amount !== undefined) updateData.amount = data.amount;
        if (data.dueDate !== undefined) updateData.dueDate = data.dueDate;
        if (data.isPaid !== undefined) {
          updateData.isPaid = data.isPaid;
          if (data.isPaid && !data.paidDate) {
            updateData.paidDate = new Date();
          }
        }
        if (data.paidDate !== undefined) updateData.paidDate = data.paidDate;
        
        return await db.updateAccount(id, updateData);
      }),
    
    delete: protectedProcedure
      .input(z.object({
        id: z.number(),
      }))
      .mutation(async ({ input }) => {
        await db.deleteAccount(input.id);
        return { success: true };
      }),
  }),

  financial: router({
    stats: protectedProcedure
      .input(z.object({
        startDate: z.date().optional(),
        endDate: z.date().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getFinancialStats(input?.startDate, input?.endDate);
      }),
  }),

  recruitment: router({
    list: protectedProcedure
      .input(z.object({
        status: z.enum(["pendente", "agendado", "concluido"]).optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getAllRecruitmentRequests(input);
      }),
    
    getById: protectedProcedure
      .input(z.object({
        id: z.number(),
      }))
      .query(async ({ input }) => {
        return await db.getRecruitmentRequestById(input.id);
      }),
    
    create: protectedProcedure
      .input(z.object({
        clientName: z.string().min(1, "Nome do cliente é obrigatório"),
        clientContact: z.string().min(1, "Contato é obrigatório"),
        serviceRequested: z.string().min(1, "Serviço solicitado é obrigatório"),
        description: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createRecruitmentRequest({
          clientName: input.clientName,
          clientContact: input.clientContact,
          serviceRequested: input.serviceRequested,
          description: input.description || null,
          status: "pendente",
        });
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        clientName: z.string().min(1, "Nome do cliente é obrigatório").optional(),
        clientContact: z.string().min(1, "Contato é obrigatório").optional(),
        serviceRequested: z.string().min(1, "Serviço solicitado é obrigatório").optional(),
        description: z.string().optional(),
        status: z.enum(["pendente", "agendado", "concluido"]).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        const updateData: any = {};
        
        if (data.clientName !== undefined) updateData.clientName = data.clientName;
        if (data.clientContact !== undefined) updateData.clientContact = data.clientContact;
        if (data.serviceRequested !== undefined) updateData.serviceRequested = data.serviceRequested;
        if (data.description !== undefined) updateData.description = data.description || null;
        if (data.status !== undefined) updateData.status = data.status;
        
        return await db.updateRecruitmentRequest(id, updateData);
      }),
    
    delete: protectedProcedure
      .input(z.object({
        id: z.number(),
      }))
      .mutation(async ({ input }) => {
        await db.deleteRecruitmentRequest(input.id);
        return { success: true };
      }),
  }),

  dashboard: router({
    stats: protectedProcedure.query(async () => {
      const [clients, products, sales, requests, meetings, lowStockProducts, financialStats] = await Promise.all([
        db.getAllCustomers(),
        db.getAllProducts(),
        db.getAllSales(),
        db.getAllRecruitmentRequests({ status: "pendente" }),
        db.getAllMeetings({ upcoming: true }),
        db.getAllProducts().then(prods => prods.filter(p => p.quantity > 0 && p.quantity < 5)),
        db.getFinancialStats(),
      ]);
      
      const recentSales = sales.slice(0, 5);
      
      return {
        totalClients: clients.length,
        totalProducts: products.length,
        totalSales: sales.length,
        pendingRequests: requests.length,
        upcomingMeetings: meetings.length,
        lowStockCount: lowStockProducts.length,
        lowStockProducts,
        recentSales,
        financialStats,
      };
    }),
  }),

  meetings: router({
    list: protectedProcedure
      .input(z.object({
        upcoming: z.boolean().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getAllMeetings(input);
      }),
    
    create: protectedProcedure
      .input(z.object({
        recruitmentRequestId: z.number().optional(),
        title: z.string().min(1, "Título é obrigatório"),
        meetingDate: z.date(),
        location: z.string().optional(),
        description: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createMeeting({
          recruitmentRequestId: input.recruitmentRequestId || null,
          title: input.title,
          meetingDate: input.meetingDate,
          location: input.location || null,
          description: input.description || null,
          status: "agendada",
        });
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().min(1, "Título é obrigatório").optional(),
        meetingDate: z.date().optional(),
        location: z.string().optional(),
        description: z.string().optional(),
        status: z.enum(["agendada", "realizada", "cancelada"]).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        const updateData: any = {};
        
        if (data.title !== undefined) updateData.title = data.title;
        if (data.meetingDate !== undefined) updateData.meetingDate = data.meetingDate;
        if (data.location !== undefined) updateData.location = data.location || null;
        if (data.description !== undefined) updateData.description = data.description || null;
        if (data.status !== undefined) updateData.status = data.status;
        
        return await db.updateMeeting(id, updateData);
      }),
    
    delete: protectedProcedure
      .input(z.object({
        id: z.number(),
      }))
      .mutation(async ({ input }) => {
        await db.deleteMeeting(input.id);
        return { success: true };
      }),
  }),


});

export type AppRouter = typeof appRouter;
