import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createTestContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("MicroTurbo Plan - Sistema Integrado", () => {
  const ctx = createTestContext();
  const caller = appRouter.createCaller(ctx);

  describe("Módulo de Clientes", () => {
    it("deve listar clientes sem erros", async () => {
      const result = await caller.customers.list();
      expect(Array.isArray(result)).toBe(true);
    });

    it("deve criar um cliente", async () => {
      const newCustomer = {
        name: "Cliente Teste",
        email: "cliente@teste.com",
        phone: "(11) 98765-4321",
        isFrequent: false,
        notes: "Cliente de teste",
      };

      const result = await caller.customers.create(newCustomer);
      expect(result).toHaveProperty("id");
      expect(result.name).toBe(newCustomer.name);
      expect(result.email).toBe(newCustomer.email);
    });
  });

  describe("Módulo de Estoque", () => {
    it("deve listar categorias sem erros", async () => {
      const result = await caller.categories.list();
      expect(Array.isArray(result)).toBe(true);
    });

    it("deve listar produtos sem erros", async () => {
      const result = await caller.products.list();
      expect(Array.isArray(result)).toBe(true);
    });

    it("deve criar uma categoria", async () => {
      const newCategory = {
        name: "Categoria Teste",
        description: "Descrição da categoria de teste",
      };

      const result = await caller.categories.create(newCategory);
      expect(result).toHaveProperty("id");
      expect(result.name).toBe(newCategory.name);
    });
  });

  describe("Módulo de Vendas", () => {
    it("deve listar vendas sem erros", async () => {
      const result = await caller.sales.list();
      expect(Array.isArray(result)).toBe(true);
    });

    it("deve obter estatísticas de vendas", async () => {
      const result = await caller.sales.stats();
      expect(result).toHaveProperty("totalSales");
      expect(result).toHaveProperty("totalRevenue");
      expect(result).toHaveProperty("salesByPaymentMethod");
      expect(result).toHaveProperty("topProducts");
      expect(Array.isArray(result.salesByPaymentMethod)).toBe(true);
      expect(Array.isArray(result.topProducts)).toBe(true);
    });
  });

  describe("Módulo Financeiro", () => {
    it("deve listar despesas sem erros", async () => {
      const result = await caller.expenses.list();
      expect(Array.isArray(result)).toBe(true);
    });

    it("deve listar contas sem erros", async () => {
      const result = await caller.accounts.list();
      expect(Array.isArray(result)).toBe(true);
    });

    it("deve obter estatísticas financeiras", async () => {
      const result = await caller.financial.stats();
      expect(result).toHaveProperty("totalRevenue");
      expect(result).toHaveProperty("totalExpenses");
      expect(result).toHaveProperty("profit");
      expect(result).toHaveProperty("pendingReceivables");
      expect(result).toHaveProperty("pendingPayables");
      expect(typeof result.totalRevenue).toBe("number");
      expect(typeof result.totalExpenses).toBe("number");
    });

    it("deve criar uma despesa", async () => {
      const newExpense = {
        name: "Despesa Teste",
        amount: 10000, // R$ 100,00
        category: "teste",
        expenseDate: new Date(),
      };

      const result = await caller.expenses.create(newExpense);
      expect(result).toHaveProperty("id");
      expect(result.name).toBe(newExpense.name);
      expect(result.amount).toBe(newExpense.amount);
    });
  });

  describe("Módulo de Recrutamento", () => {
    it("deve listar solicitações sem erros", async () => {
      const result = await caller.recruitment.list();
      expect(Array.isArray(result)).toBe(true);
    });

    it("deve listar reuniões sem erros", async () => {
      const result = await caller.meetings.list();
      expect(Array.isArray(result)).toBe(true);
    });

    it("deve criar uma solicitação de recrutamento", async () => {
      const newRequest = {
        clientName: "Cliente Solicitante",
        clientContact: "contato@cliente.com",
        serviceRequested: "Serviço de Teste",
        description: "Descrição do serviço solicitado",
      };

      const result = await caller.recruitment.create(newRequest);
      expect(result).toHaveProperty("id");
      expect(result.clientName).toBe(newRequest.clientName);
      expect(result.status).toBe("pendente");
    });
  });

  describe("Dashboard", () => {
    it("deve obter estatísticas do dashboard", async () => {
      const result = await caller.dashboard.stats();
      expect(result).toHaveProperty("totalClients");
      expect(result).toHaveProperty("totalProducts");
      expect(result).toHaveProperty("totalSales");
      expect(result).toHaveProperty("pendingRequests");
      expect(result).toHaveProperty("upcomingMeetings");
      expect(result).toHaveProperty("lowStockCount");
      expect(result).toHaveProperty("financialStats");
      expect(typeof result.totalClients).toBe("number");
      expect(typeof result.totalProducts).toBe("number");
      expect(typeof result.totalSales).toBe("number");
    });
  });

  describe("Autenticação", () => {
    it("deve retornar informações do usuário autenticado", async () => {
      const result = await caller.auth.me();
      expect(result).toHaveProperty("id");
      expect(result).toHaveProperty("email");
      expect(result).toHaveProperty("name");
      expect(result?.email).toBe("test@example.com");
    });
  });
});
