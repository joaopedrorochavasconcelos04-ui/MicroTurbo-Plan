import { eq, desc, like, or, and, lt, gte, lte, sql, between } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users, customers, InsertCustomer, Customer,
  categories, InsertCategory, Category,
  products, InsertProduct, Product,
  stockMovements, InsertStockMovement, StockMovement,
  sales, InsertSale, Sale,
  saleItems, InsertSaleItem, SaleItem,
  expenses, InsertExpense, Expense,
  accounts, InsertAccount, Account,
  recruitmentRequests, InsertRecruitmentRequest, RecruitmentRequest,
  meetings, InsertMeeting, Meeting
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// === Customer Functions ===

export async function getAllCustomers(searchTerm?: string): Promise<Customer[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get customers: database not available");
    return [];
  }

  if (searchTerm) {
    return await db
      .select()
      .from(customers)
      .where(
        or(
          like(customers.name, `%${searchTerm}%`),
          like(customers.email, `%${searchTerm}%`),
          like(customers.phone, `%${searchTerm}%`)
        )
      )
      .orderBy(desc(customers.createdAt));
  }

  return await db.select().from(customers).orderBy(desc(customers.createdAt));
}

export async function getCustomerById(id: number): Promise<Customer | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get customer: database not available");
    return undefined;
  }

  const result = await db.select().from(customers).where(eq(customers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createCustomer(data: InsertCustomer): Promise<Customer> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(customers).values(data);
  const insertedId = Number(result[0].insertId);
  
  const customer = await getCustomerById(insertedId);
  if (!customer) {
    throw new Error("Failed to retrieve created customer");
  }
  
  return customer;
}

export async function updateCustomer(id: number, data: Partial<InsertCustomer>): Promise<Customer> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.update(customers).set(data).where(eq(customers.id, id));
  
  const customer = await getCustomerById(id);
  if (!customer) {
    throw new Error("Customer not found after update");
  }
  
  return customer;
}

export async function deleteCustomer(id: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.delete(customers).where(eq(customers.id, id));
}

// === Category Functions ===

export async function getAllCategories(): Promise<Category[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get categories: database not available");
    return [];
  }

  return await db.select().from(categories).orderBy(categories.name);
}

export async function createCategory(data: InsertCategory): Promise<Category> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(categories).values(data);
  const insertedId = Number(result[0].insertId);
  
  const category = await db.select().from(categories).where(eq(categories.id, insertedId)).limit(1);
  if (!category[0]) {
    throw new Error("Failed to retrieve created category");
  }
  
  return category[0];
}

// === Product Functions ===

export async function getAllProducts(searchTerm?: string, categoryId?: number): Promise<Product[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get products: database not available");
    return [];
  }

  let query = db.select().from(products);
  
  const conditions = [];
  if (searchTerm) {
    conditions.push(
      or(
        like(products.name, `%${searchTerm}%`),
        like(products.description, `%${searchTerm}%`)
      )
    );
  }
  if (categoryId) {
    conditions.push(eq(products.categoryId, categoryId));
  }
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }
  
  return await query.orderBy(desc(products.createdAt));
}

export async function getProductById(id: number): Promise<Product | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get product: database not available");
    return undefined;
  }

  const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getLowStockProducts(): Promise<Product[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get low stock products: database not available");
    return [];
  }

  return await db
    .select()
    .from(products)
    .where(
      or(
        eq(products.quantity, 0),
        and(
          lt(products.quantity, products.minQuantity),
          eq(products.quantity, products.quantity) // Always true, just to use 'and'
        )
      )
    )
    .orderBy(products.quantity);
}

export async function createProduct(data: InsertProduct): Promise<Product> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(products).values(data);
  const insertedId = Number(result[0].insertId);
  
  const product = await getProductById(insertedId);
  if (!product) {
    throw new Error("Failed to retrieve created product");
  }
  
  return product;
}

export async function updateProduct(id: number, data: Partial<InsertProduct>): Promise<Product> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.update(products).set(data).where(eq(products.id, id));
  
  const product = await getProductById(id);
  if (!product) {
    throw new Error("Product not found after update");
  }
  
  return product;
}

export async function deleteProduct(id: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.delete(products).where(eq(products.id, id));
}

// === Stock Movement Functions ===

export async function getStockMovementsByProduct(productId: number): Promise<StockMovement[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get stock movements: database not available");
    return [];
  }

  return await db
    .select()
    .from(stockMovements)
    .where(eq(stockMovements.productId, productId))
    .orderBy(desc(stockMovements.createdAt));
}

export async function createStockMovement(
  data: InsertStockMovement,
  updateQuantity: boolean = true
): Promise<StockMovement> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // Insert movement
  const result = await db.insert(stockMovements).values(data);
  const insertedId = Number(result[0].insertId);
  
  // Update product quantity if requested
  if (updateQuantity) {
    const product = await getProductById(data.productId);
    if (product) {
      const newQuantity = data.type === "entrada" 
        ? product.quantity + data.quantity
        : product.quantity - data.quantity;
      
      await updateProduct(data.productId, { quantity: Math.max(0, newQuantity) });
    }
  }
  
  const movement = await db
    .select()
    .from(stockMovements)
    .where(eq(stockMovements.id, insertedId))
    .limit(1);
    
  if (!movement[0]) {
    throw new Error("Failed to retrieve created stock movement");
  }
  
  return movement[0];
}

// === Sales Functions ===

export async function getAllSales(filters?: {
  startDate?: Date;
  endDate?: Date;
  customerId?: number;
  paymentMethod?: string;
}): Promise<Sale[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get sales: database not available");
    return [];
  }

  let query = db.select().from(sales);
  
  const conditions = [];
  if (filters?.startDate) {
    conditions.push(gte(sales.saleDate, filters.startDate));
  }
  if (filters?.endDate) {
    conditions.push(lte(sales.saleDate, filters.endDate));
  }
  if (filters?.customerId) {
    conditions.push(eq(sales.customerId, filters.customerId));
  }
  if (filters?.paymentMethod) {
    conditions.push(eq(sales.paymentMethod, filters.paymentMethod as any));
  }
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }
  
  return await query.orderBy(desc(sales.saleDate));
}

export async function getSaleById(id: number): Promise<Sale | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get sale: database not available");
    return undefined;
  }

  const result = await db.select().from(sales).where(eq(sales.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getSaleItems(saleId: number): Promise<SaleItem[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get sale items: database not available");
    return [];
  }

  return await db.select().from(saleItems).where(eq(saleItems.saleId, saleId));
}

export async function createSale(
  saleData: InsertSale,
  items: Omit<InsertSaleItem, "saleId">[]
): Promise<Sale> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // Insert sale
  const result = await db.insert(sales).values(saleData);
  const saleId = Number(result[0].insertId);
  
  // Insert sale items
  if (items.length > 0) {
    const itemsWithSaleId = items.map(item => ({
      ...item,
      saleId,
    }));
    await db.insert(saleItems).values(itemsWithSaleId);
    
    // Update product quantities (create stock movements)
    for (const item of items) {
      if (item.productId) {
        await createStockMovement({
          productId: item.productId,
          type: "saida",
          quantity: item.quantity,
          reason: `Venda #${saleId}`,
          createdBy: saleData.createdBy,
        });
      }
    }
  }
  
  const sale = await getSaleById(saleId);
  if (!sale) {
    throw new Error("Failed to retrieve created sale");
  }
  
  return sale;
}

export async function updateSale(
  id: number,
  data: Partial<InsertSale>
): Promise<Sale> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.update(sales).set(data).where(eq(sales.id, id));
  
  const sale = await getSaleById(id);
  if (!sale) {
    throw new Error("Sale not found after update");
  }
  
  return sale;
}

export async function deleteSale(id: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // Items will be deleted automatically due to cascade
  await db.delete(sales).where(eq(sales.id, id));
}

// === Sales Analytics ===

export async function getSalesStats(startDate?: Date, endDate?: Date) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get sales stats: database not available");
    return {
      totalSales: 0,
      totalRevenue: 0,
      salesByPaymentMethod: [],
      topProducts: [],
      salesByWeek: [],
      salesByMonth: [],
    };
  }

  const conditions = [];
  if (startDate) {
    conditions.push(gte(sales.saleDate, startDate));
  }
  if (endDate) {
    conditions.push(lte(sales.saleDate, endDate));
  }

  // Total sales and revenue
  let salesQuery = db.select({
    count: sql<number>`COUNT(*)`,
    total: sql<number>`COALESCE(SUM(${sales.total}), 0)`,
  }).from(sales);
  
  if (conditions.length > 0) {
    salesQuery = salesQuery.where(and(...conditions)) as any;
  }
  
  const [totals] = await salesQuery;

  // Sales by payment method
  let paymentQuery = db.select({
    paymentMethod: sales.paymentMethod,
    count: sql<number>`COUNT(*)`,
    total: sql<number>`COALESCE(SUM(${sales.total}), 0)`,
  }).from(sales).groupBy(sales.paymentMethod);
  
  if (conditions.length > 0) {
    paymentQuery = paymentQuery.where(and(...conditions)) as any;
  }
  
  const salesByPaymentMethod = await paymentQuery;

  // Top products
  let topProductsQuery = db.select({
    productName: saleItems.productName,
    quantity: sql<number>`SUM(${saleItems.quantity})`,
    revenue: sql<number>`SUM(${saleItems.subtotal})`,
  })
  .from(saleItems)
  .innerJoin(sales, eq(saleItems.saleId, sales.id))
  .groupBy(saleItems.productName)
  .orderBy(desc(sql`SUM(${saleItems.quantity})`));
  
  if (conditions.length > 0) {
    topProductsQuery = topProductsQuery.where(and(...conditions)) as any;
  }
  
  const topProducts = await topProductsQuery.limit(10);

  // Sales by week (last 8 weeks)
  const eightWeeksAgo = new Date();
  eightWeeksAgo.setDate(eightWeeksAgo.getDate() - 56);
  
  const salesByWeekQuery = db.select({
    week: sql<string>`DATE_FORMAT(${sales.saleDate}, '%Y-%u')`,
    weekLabel: sql<string>`CONCAT('Semana ', WEEK(${sales.saleDate}, 1))`,
    count: sql<number>`COUNT(*)`,
    total: sql<number>`COALESCE(SUM(${sales.total}), 0)`,
  })
  .from(sales)
  .where(gte(sales.saleDate, eightWeeksAgo))
  .groupBy(sql`DATE_FORMAT(${sales.saleDate}, '%Y-%u')`)
  .orderBy(sql`DATE_FORMAT(${sales.saleDate}, '%Y-%u')`);
  
  const salesByWeek = await salesByWeekQuery;

  // Sales by month (last 6 months)
  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
  
  const salesByMonthQuery = db.select({
    month: sql<string>`DATE_FORMAT(${sales.saleDate}, '%Y-%m')`,
    monthLabel: sql<string>`DATE_FORMAT(${sales.saleDate}, '%b/%Y')`,
    count: sql<number>`COUNT(*)`,
    total: sql<number>`COALESCE(SUM(${sales.total}), 0)`,
  })
  .from(sales)
  .where(gte(sales.saleDate, sixMonthsAgo))
  .groupBy(sql`DATE_FORMAT(${sales.saleDate}, '%Y-%m')`)
  .orderBy(sql`DATE_FORMAT(${sales.saleDate}, '%Y-%m')`);
  
  const salesByMonth = await salesByMonthQuery;

  return {
    totalSales: Number(totals?.count || 0),
    totalRevenue: Number(totals?.total || 0),
    salesByPaymentMethod,
    topProducts,
    salesByWeek,
    salesByMonth,
  };
}

// === Expense Functions ===

export async function getAllExpenses(filters?: {
  startDate?: Date;
  endDate?: Date;
  category?: string;
}): Promise<Expense[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get expenses: database not available");
    return [];
  }

  let query = db.select().from(expenses);
  
  const conditions = [];
  if (filters?.startDate) {
    conditions.push(gte(expenses.expenseDate, filters.startDate));
  }
  if (filters?.endDate) {
    conditions.push(lte(expenses.expenseDate, filters.endDate));
  }
  if (filters?.category) {
    conditions.push(eq(expenses.category, filters.category));
  }
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }
  
  return await query.orderBy(desc(expenses.expenseDate));
}

export async function getExpenseById(id: number): Promise<Expense | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get expense: database not available");
    return undefined;
  }

  const result = await db.select().from(expenses).where(eq(expenses.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createExpense(data: InsertExpense): Promise<Expense> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(expenses).values(data);
  const insertedId = Number(result[0].insertId);
  
  const expense = await getExpenseById(insertedId);
  if (!expense) {
    throw new Error("Failed to retrieve created expense");
  }
  
  return expense;
}

export async function updateExpense(id: number, data: Partial<InsertExpense>): Promise<Expense> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.update(expenses).set(data).where(eq(expenses.id, id));
  
  const expense = await getExpenseById(id);
  if (!expense) {
    throw new Error("Expense not found after update");
  }
  
  return expense;
}

export async function deleteExpense(id: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.delete(expenses).where(eq(expenses.id, id));
}

// === Account Functions ===

export async function getAllAccounts(filters?: {
  type?: "pagar" | "receber";
  isPaid?: boolean;
  dueSoon?: boolean;
}): Promise<Account[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get accounts: database not available");
    return [];
  }

  let query = db.select().from(accounts);
  
  const conditions = [];
  if (filters?.type) {
    conditions.push(eq(accounts.type, filters.type));
  }
  if (filters?.isPaid !== undefined) {
    conditions.push(eq(accounts.isPaid, filters.isPaid));
  }
  if (filters?.dueSoon) {
    const today = new Date();
    const nextWeek = new Date();
    nextWeek.setDate(today.getDate() + 7);
    conditions.push(
      and(
        eq(accounts.isPaid, false),
        lte(accounts.dueDate, nextWeek)
      )
    );
  }
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }
  
  return await query.orderBy(accounts.dueDate);
}

export async function getAccountById(id: number): Promise<Account | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get account: database not available");
    return undefined;
  }

  const result = await db.select().from(accounts).where(eq(accounts.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createAccount(data: InsertAccount): Promise<Account> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(accounts).values(data);
  const insertedId = Number(result[0].insertId);
  
  const account = await getAccountById(insertedId);
  if (!account) {
    throw new Error("Failed to retrieve created account");
  }
  
  return account;
}

export async function updateAccount(id: number, data: Partial<InsertAccount>): Promise<Account> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.update(accounts).set(data).where(eq(accounts.id, id));
  
  const account = await getAccountById(id);
  if (!account) {
    throw new Error("Account not found after update");
  }
  
  return account;
}

export async function deleteAccount(id: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.delete(accounts).where(eq(accounts.id, id));
}

// === Financial Stats ===

export async function getFinancialStats(startDate?: Date, endDate?: Date) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get financial stats: database not available");
    return {
      totalRevenue: 0,
      totalExpenses: 0,
      profit: 0,
      pendingReceivables: 0,
      pendingPayables: 0,
      revenueByMonth: [],
      expensesByMonth: [],
    };
  }

  const conditions = [];
  if (startDate) {
    conditions.push(gte(sales.saleDate, startDate));
  }
  if (endDate) {
    conditions.push(lte(sales.saleDate, endDate));
  }

  // Total revenue from sales
  let revenueQuery = db.select({
    total: sql<number>`COALESCE(SUM(${sales.total}), 0)`,
  }).from(sales);
  
  if (conditions.length > 0) {
    revenueQuery = revenueQuery.where(and(...conditions)) as any;
  }
  
  const [revenue] = await revenueQuery;

  // Total expenses
  const expenseConditions = [];
  if (startDate) {
    expenseConditions.push(gte(expenses.expenseDate, startDate));
  }
  if (endDate) {
    expenseConditions.push(lte(expenses.expenseDate, endDate));
  }

  let expenseQuery = db.select({
    total: sql<number>`COALESCE(SUM(${expenses.amount}), 0)`,
  }).from(expenses);
  
  if (expenseConditions.length > 0) {
    expenseQuery = expenseQuery.where(and(...expenseConditions)) as any;
  }
  
  const [expense] = await expenseQuery;

  // Pending receivables
  const [receivables] = await db.select({
    total: sql<number>`COALESCE(SUM(${accounts.amount}), 0)`,
  }).from(accounts).where(
    and(
      eq(accounts.type, "receber"),
      eq(accounts.isPaid, false)
    )
  );

  // Pending payables
  const [payables] = await db.select({
    total: sql<number>`COALESCE(SUM(${accounts.amount}), 0)`,
  }).from(accounts).where(
    and(
      eq(accounts.type, "pagar"),
      eq(accounts.isPaid, false)
    )
  );

  const totalRevenue = Number(revenue?.total || 0);
  const totalExpenses = Number(expense?.total || 0);

  // Revenue by month (last 6 months)
  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
  
  const revenueByMonthQuery = db.select({
    month: sql<string>`DATE_FORMAT(${sales.saleDate}, '%Y-%m')`,
    monthLabel: sql<string>`DATE_FORMAT(${sales.saleDate}, '%b/%Y')`,
    total: sql<number>`COALESCE(SUM(${sales.total}), 0)`,
  })
  .from(sales)
  .where(gte(sales.saleDate, sixMonthsAgo))
  .groupBy(sql`DATE_FORMAT(${sales.saleDate}, '%Y-%m')`)
  .orderBy(sql`DATE_FORMAT(${sales.saleDate}, '%Y-%m')`);
  
  const revenueByMonth = await revenueByMonthQuery;

  // Expenses by month (last 6 months)
  const expensesByMonthQuery = db.select({
    month: sql<string>`DATE_FORMAT(${expenses.expenseDate}, '%Y-%m')`,
    monthLabel: sql<string>`DATE_FORMAT(${expenses.expenseDate}, '%b/%Y')`,
    total: sql<number>`COALESCE(SUM(${expenses.amount}), 0)`,
  })
  .from(expenses)
  .where(gte(expenses.expenseDate, sixMonthsAgo))
  .groupBy(sql`DATE_FORMAT(${expenses.expenseDate}, '%Y-%m')`)
  .orderBy(sql`DATE_FORMAT(${expenses.expenseDate}, '%Y-%m')`);
  
  const expensesByMonth = await expensesByMonthQuery;

  return {
    totalRevenue,
    totalExpenses,
    profit: totalRevenue - totalExpenses,
    pendingReceivables: Number(receivables?.total || 0),
    pendingPayables: Number(payables?.total || 0),
    revenueByMonth,
    expensesByMonth,
  };
}

// === Recruitment Request Functions ===

export async function getAllRecruitmentRequests(filters?: {
  status?: "pendente" | "agendado" | "concluido";
}): Promise<RecruitmentRequest[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get recruitment requests: database not available");
    return [];
  }

  let query = db.select().from(recruitmentRequests);
  
  if (filters?.status) {
    query = query.where(eq(recruitmentRequests.status, filters.status)) as any;
  }
  
  return await query.orderBy(desc(recruitmentRequests.createdAt));
}

export async function getRecruitmentRequestById(id: number): Promise<RecruitmentRequest | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get recruitment request: database not available");
    return undefined;
  }

  const result = await db.select().from(recruitmentRequests).where(eq(recruitmentRequests.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createRecruitmentRequest(data: InsertRecruitmentRequest): Promise<RecruitmentRequest> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(recruitmentRequests).values(data);
  const insertedId = Number(result[0].insertId);
  
  const request = await getRecruitmentRequestById(insertedId);
  if (!request) {
    throw new Error("Failed to retrieve created recruitment request");
  }
  
  return request;
}

export async function updateRecruitmentRequest(id: number, data: Partial<InsertRecruitmentRequest>): Promise<RecruitmentRequest> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.update(recruitmentRequests).set(data).where(eq(recruitmentRequests.id, id));
  
  const request = await getRecruitmentRequestById(id);
  if (!request) {
    throw new Error("Recruitment request not found after update");
  }
  
  return request;
}

export async function deleteRecruitmentRequest(id: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.delete(recruitmentRequests).where(eq(recruitmentRequests.id, id));
}

// === Meeting Functions ===

export async function getAllMeetings(filters?: {
  upcoming?: boolean;
}): Promise<Meeting[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get meetings: database not available");
    return [];
  }

  let query = db.select().from(meetings);
  
  if (filters?.upcoming) {
    query = query.where(gte(meetings.meetingDate, new Date())) as any;
  }
  
  return await query.orderBy(meetings.meetingDate);
}

export async function getMeetingById(id: number): Promise<Meeting | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get meeting: database not available");
    return undefined;
  }

  const result = await db.select().from(meetings).where(eq(meetings.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createMeeting(data: InsertMeeting): Promise<Meeting> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(meetings).values(data);
  const insertedId = Number(result[0].insertId);
  
  const meeting = await getMeetingById(insertedId);
  if (!meeting) {
    throw new Error("Failed to retrieve created meeting");
  }
  
  return meeting;
}

export async function updateMeeting(id: number, data: Partial<InsertMeeting>): Promise<Meeting> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.update(meetings).set(data).where(eq(meetings.id, id));
  
  const meeting = await getMeetingById(id);
  if (!meeting) {
    throw new Error("Meeting not found after update");
  }
  
  return meeting;
}

export async function deleteMeeting(id: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.delete(meetings).where(eq(meetings.id, id));
}
