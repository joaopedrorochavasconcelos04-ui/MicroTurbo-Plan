import { drizzle } from "drizzle-orm/mysql2";
import { eq } from "drizzle-orm";
import mysql from "mysql2/promise";
import * as schema from "./drizzle/schema.js";

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error("DATABASE_URL não está definida");
  process.exit(1);
}

const connection = await mysql.createConnection(DATABASE_URL);
const db = drizzle(connection, { schema, mode: "default" });

console.log("🌱 Iniciando seed do banco de dados...\n");

// Limpar dados existentes (exceto usuários)
console.log("🗑️  Limpando dados antigos...");
await db.delete(schema.saleItems);
await db.delete(schema.sales);
await db.delete(schema.stockMovements);
await db.delete(schema.products);
await db.delete(schema.categories);
await db.delete(schema.customers);
await db.delete(schema.expenses);
await db.delete(schema.accounts);
await db.delete(schema.meetings);
await db.delete(schema.recruitmentRequests);
console.log("✅ Dados antigos removidos\n");

// 1. Criar Categorias
console.log("📦 Criando categorias...");
const categoriesData = [
  { name: "Eletrônicos", description: "Produtos eletrônicos e acessórios" },
  { name: "Roupas", description: "Vestuário e acessórios de moda" },
  { name: "Alimentos", description: "Produtos alimentícios" },
  { name: "Livros", description: "Livros e materiais de leitura" },
  { name: "Cosméticos", description: "Produtos de beleza e higiene" },
  { name: "Esportes", description: "Artigos esportivos e fitness" },
];

for (const cat of categoriesData) {
  await db.insert(schema.categories).values(cat);
}
console.log(`✅ ${categoriesData.length} categorias criadas\n`);

// Buscar IDs das categorias
const categories = await db.select().from(schema.categories);
const categoryMap = Object.fromEntries(categories.map(c => [c.name, c.id]));

// 2. Criar Produtos
console.log("🛍️  Criando produtos...");
const productsData = [
  // Eletrônicos
  { name: "Fone de Ouvido Bluetooth", categoryId: categoryMap["Eletrônicos"], price: 8900, quantity: 15, description: "Fone sem fio com cancelamento de ruído" },
  { name: "Mouse Gamer RGB", categoryId: categoryMap["Eletrônicos"], price: 12500, quantity: 8, description: "Mouse óptico com 7 botões programáveis" },
  { name: "Teclado Mecânico", categoryId: categoryMap["Eletrônicos"], price: 25000, quantity: 4, description: "Teclado mecânico com switches blue" },
  { name: "Webcam HD", categoryId: categoryMap["Eletrônicos"], price: 15000, quantity: 12, description: "Câmera 1080p para streaming" },
  { name: "Carregador Portátil", categoryId: categoryMap["Eletrônicos"], price: 6500, quantity: 20, description: "Power bank 10000mAh" },
  { name: "Cabo USB-C", categoryId: categoryMap["Eletrônicos"], price: 2500, quantity: 2, description: "Cabo de 2 metros" },
  
  // Roupas
  { name: "Camiseta Básica", categoryId: categoryMap["Roupas"], price: 3500, quantity: 25, description: "100% algodão" },
  { name: "Calça Jeans", categoryId: categoryMap["Roupas"], price: 8900, quantity: 10, description: "Jeans slim fit" },
  { name: "Jaqueta de Couro", categoryId: categoryMap["Roupas"], price: 35000, quantity: 3, description: "Couro legítimo" },
  { name: "Tênis Esportivo", categoryId: categoryMap["Roupas"], price: 18000, quantity: 7, description: "Ideal para corrida" },
  { name: "Boné", categoryId: categoryMap["Roupas"], price: 4500, quantity: 18, description: "Ajustável" },
  
  // Alimentos
  { name: "Café Premium 500g", categoryId: categoryMap["Alimentos"], price: 2800, quantity: 30, description: "Café torrado e moído" },
  { name: "Chocolate Artesanal", categoryId: categoryMap["Alimentos"], price: 1500, quantity: 1, description: "70% cacau" },
  { name: "Biscoitos Integrais", categoryId: categoryMap["Alimentos"], price: 850, quantity: 40, description: "Sem açúcar" },
  { name: "Mel Orgânico", categoryId: categoryMap["Alimentos"], price: 3200, quantity: 15, description: "500ml puro" },
  
  // Livros
  { name: "Livro: Gestão de Negócios", categoryId: categoryMap["Livros"], price: 4500, quantity: 12, description: "Guia completo" },
  { name: "Livro: Marketing Digital", categoryId: categoryMap["Livros"], price: 5200, quantity: 8, description: "Estratégias modernas" },
  { name: "Livro: Finanças Pessoais", categoryId: categoryMap["Livros"], price: 3800, quantity: 0, description: "Educação financeira" },
  
  // Cosméticos
  { name: "Shampoo Hidratante", categoryId: categoryMap["Cosméticos"], price: 2800, quantity: 22, description: "400ml" },
  { name: "Creme Facial", categoryId: categoryMap["Cosméticos"], price: 6500, quantity: 10, description: "Anti-idade" },
  { name: "Perfume Importado", categoryId: categoryMap["Cosméticos"], price: 25000, quantity: 5, description: "100ml" },
  { name: "Batom Matte", categoryId: categoryMap["Cosméticos"], price: 1800, quantity: 3, description: "Longa duração" },
  
  // Esportes
  { name: "Garrafa Térmica", categoryId: categoryMap["Esportes"], price: 5500, quantity: 14, description: "1 litro" },
  { name: "Tapete de Yoga", categoryId: categoryMap["Esportes"], price: 8900, quantity: 6, description: "Antiderrapante" },
  { name: "Halteres 5kg (par)", categoryId: categoryMap["Esportes"], price: 12000, quantity: 8, description: "Emborrachados" },
  { name: "Corda de Pular", categoryId: categoryMap["Esportes"], price: 2500, quantity: 20, description: "Ajustável" },
];

for (const prod of productsData) {
  await db.insert(schema.products).values(prod);
}
console.log(`✅ ${productsData.length} produtos criados\n`);

// Buscar IDs dos produtos
const products = await db.select().from(schema.products);

// 3. Criar Clientes
console.log("👥 Criando clientes...");
const customersData = [
  { name: "Maria Silva", email: "maria.silva@email.com", phone: "(11) 98765-4321", observations: "Cliente fiel - compra mensalmente", isFrequent: true },
  { name: "João Santos", email: "joao.santos@email.com", phone: "(11) 97654-3210", observations: null, isFrequent: false },
  { name: "Ana Costa", email: "ana.costa@email.com", phone: "(11) 96543-2109", observations: "Prefere pagamento em PIX", isFrequent: true },
  { name: "Pedro Oliveira", email: "pedro.oliveira@email.com", phone: "(11) 95432-1098", observations: null, isFrequent: false },
  { name: "Carla Souza", email: "carla.souza@email.com", phone: "(11) 94321-0987", observations: "Cliente VIP - sempre compra produtos premium", isFrequent: true },
  { name: "Lucas Ferreira", email: "lucas.ferreira@email.com", phone: "(11) 93210-9876", observations: null, isFrequent: false },
  { name: "Juliana Lima", email: "juliana.lima@email.com", phone: "(11) 92109-8765", observations: "Gosta de promoções", isFrequent: true },
  { name: "Ricardo Alves", email: "ricardo.alves@email.com", phone: "(11) 91098-7654", observations: null, isFrequent: false },
  { name: "Fernanda Rocha", email: "fernanda.rocha@email.com", phone: "(11) 90987-6543", observations: "Cliente corporativo", isFrequent: true },
  { name: "Bruno Martins", email: "bruno.martins@email.com", phone: "(11) 89876-5432", observations: null, isFrequent: false },
  { name: "Patricia Gomes", email: "patricia.gomes@email.com", phone: "(11) 88765-4321", observations: "Compra para revenda", isFrequent: true },
  { name: "Roberto Dias", email: "roberto.dias@email.com", phone: "(11) 87654-3210", observations: null, isFrequent: false },
];

for (const customer of customersData) {
  await db.insert(schema.customers).values(customer);
}
console.log(`✅ ${customersData.length} clientes criados\n`);

// Buscar IDs dos clientes
const customers = await db.select().from(schema.customers);

// 4. Criar Vendas (últimos 3 meses)
console.log("💰 Criando vendas...");
const paymentMethods = ["dinheiro", "cartao_credito", "cartao_debito", "pix", "transferencia"];
const now = new Date();
let salesCount = 0;

// Função auxiliar para gerar data aleatória nos últimos 3 meses
function randomDate(daysAgo) {
  const date = new Date(now);
  date.setDate(date.getDate() - daysAgo);
  date.setHours(Math.floor(Math.random() * 12) + 8); // Entre 8h e 20h
  date.setMinutes(Math.floor(Math.random() * 60));
  return date;
}

// Função auxiliar para selecionar itens aleatórios
function randomItems(arr, count) {
  const shuffled = [...arr].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
}

// Gerar vendas distribuídas nos últimos 90 dias
for (let day = 0; day < 90; day++) {
  // Mais vendas nos fins de semana e menos durante a semana
  const salesPerDay = [0, 1, 2, 3, 4].includes(new Date(now.getTime() - day * 24 * 60 * 60 * 1000).getDay()) 
    ? Math.floor(Math.random() * 3) + 1  // 1-3 vendas em dias de semana
    : Math.floor(Math.random() * 4) + 2; // 2-5 vendas em fins de semana
  
  for (let i = 0; i < salesPerDay; i++) {
    const customer = customers[Math.floor(Math.random() * customers.length)];
    const paymentMethod = paymentMethods[Math.floor(Math.random() * paymentMethods.length)];
    const saleDate = randomDate(day);
    
    // Selecionar 1-4 produtos aleatórios
    const itemCount = Math.floor(Math.random() * 4) + 1;
    const selectedProducts = randomItems(products, itemCount);
    
    let total = 0;
    const items = selectedProducts.map(product => {
      const quantity = Math.floor(Math.random() * 3) + 1; // 1-3 unidades
      const subtotal = product.price * quantity;
      total += subtotal;
      return {
        productId: product.id,
        productName: product.name,
        quantity,
        unitPrice: product.price,
        subtotal,
      };
    });
    
    // Inserir venda
    const saleResult = await db.insert(schema.sales).values({
      customerId: customer.id,
      customerName: customer.name,
      saleDate,
      paymentMethod,
      total,
      observations: Math.random() > 0.8 ? "Venda com desconto especial" : null,
    });
    
    const saleId = Number(saleResult[0].insertId);
    
    // Inserir itens da venda
    for (const item of items) {
      await db.insert(schema.saleItems).values({
        saleId,
        ...item,
      });
      
      // Atualizar estoque (diminuir quantidade)
      const product = products.find(p => p.id === item.productId);
      if (product) {
        product.quantity = Math.max(0, product.quantity - item.quantity);
        await db.update(schema.products)
          .set({ quantity: product.quantity })
          .where(eq(schema.products.id, product.id));
      }
    }
    
    salesCount++;
  }
}
console.log(`✅ ${salesCount} vendas criadas\n`);

// 5. Criar Despesas
console.log("💸 Criando despesas...");
const expenseCategories = ["Aluguel", "Energia", "Internet", "Fornecedores", "Marketing", "Salários", "Manutenção", "Impostos"];
const expensesData = [];

for (let month = 0; month < 3; month++) {
  const monthDate = new Date(now);
  monthDate.setMonth(monthDate.getMonth() - month);
  
  // Aluguel mensal
  expensesData.push({
    name: "Aluguel do estabelecimento",
    amount: 250000, // R$ 2.500,00
    category: "Aluguel",
    expenseDate: new Date(monthDate.getFullYear(), monthDate.getMonth(), 5),
    description: "Pagamento mensal do aluguel",
  });
  
  // Energia
  expensesData.push({
    name: "Conta de energia",
    amount: Math.floor(Math.random() * 20000) + 30000, // R$ 300-500
    category: "Energia",
    expenseDate: new Date(monthDate.getFullYear(), monthDate.getMonth(), 10),
    description: null,
  });
  
  // Internet
  expensesData.push({
    name: "Internet fibra óptica",
    amount: 12000, // R$ 120,00
    category: "Internet",
    expenseDate: new Date(monthDate.getFullYear(), monthDate.getMonth(), 15),
    description: "Plano 500MB",
  });
  
  // Fornecedores (2-3 por mês)
  const supplierCount = Math.floor(Math.random() * 2) + 2;
  for (let i = 0; i < supplierCount; i++) {
    expensesData.push({
      name: `Compra de mercadorias - Fornecedor ${i + 1}`,
      amount: Math.floor(Math.random() * 150000) + 50000, // R$ 500-2000
      category: "Fornecedores",
      expenseDate: randomDate(month * 30 + Math.floor(Math.random() * 30)),
      description: "Reposição de estoque",
    });
  }
  
  // Marketing
  if (Math.random() > 0.5) {
    expensesData.push({
      name: "Anúncios online",
      amount: Math.floor(Math.random() * 30000) + 20000, // R$ 200-500
      category: "Marketing",
      expenseDate: randomDate(month * 30 + Math.floor(Math.random() * 30)),
      description: "Google Ads e Facebook Ads",
    });
  }
}

for (const expense of expensesData) {
  await db.insert(schema.expenses).values(expense);
}
console.log(`✅ ${expensesData.length} despesas criadas\n`);

// 6. Criar Contas a Pagar e Receber
console.log("📋 Criando contas a pagar/receber...");
const accountsData = [];

// Contas a pagar (futuras)
for (let i = 0; i < 5; i++) {
  const daysAhead = Math.floor(Math.random() * 30) + 1;
  const dueDate = new Date(now);
  dueDate.setDate(dueDate.getDate() + daysAhead);
  
  accountsData.push({
    type: "pagar",
    description: `Fornecedor ${i + 1} - Pedido #${1000 + i}`,
    amount: Math.floor(Math.random() * 100000) + 50000,
    dueDate,
    isPaid: false,
  });
}

// Contas a receber (futuras)
for (let i = 0; i < 3; i++) {
  const daysAhead = Math.floor(Math.random() * 20) + 1;
  const dueDate = new Date(now);
  dueDate.setDate(dueDate.getDate() + daysAhead);
  
  accountsData.push({
    type: "receber",
    description: `Cliente ${customers[i].name} - Venda parcelada`,
    amount: Math.floor(Math.random() * 80000) + 30000,
    dueDate,
    isPaid: false,
  });
}

// Algumas contas já pagas
for (let i = 0; i < 4; i++) {
  const daysAgo = Math.floor(Math.random() * 15) + 1;
  const dueDate = new Date(now);
  dueDate.setDate(dueDate.getDate() - daysAgo);
  
  accountsData.push({
    type: Math.random() > 0.5 ? "pagar" : "receber",
    description: `Conta paga - Referência #${2000 + i}`,
    amount: Math.floor(Math.random() * 50000) + 20000,
    dueDate,
    isPaid: true,
  });
}

for (const account of accountsData) {
  await db.insert(schema.accounts).values(account);
}
console.log(`✅ ${accountsData.length} contas criadas\n`);

// 7. Criar Solicitações de Recrutamento
console.log("🤝 Criando solicitações de recrutamento...");
const recruitmentData = [
  {
    clientName: "Tech Solutions Ltda",
    clientContact: "contato@techsolutions.com.br | (11) 3456-7890",
    serviceRequested: "Desenvolvedor Full Stack",
    description: "Precisamos de um desenvolvedor experiente em React e Node.js para projeto de 6 meses",
    status: "pendente",
  },
  {
    clientName: "Marketing Pro",
    clientContact: "rh@marketingpro.com.br | (11) 3456-7891",
    serviceRequested: "Designer Gráfico",
    description: "Vaga para designer com experiência em Photoshop e Illustrator",
    status: "em_analise",
  },
  {
    clientName: "Consultoria Empresarial",
    clientContact: "contato@consultoria.com.br | (11) 3456-7892",
    serviceRequested: "Contador",
    description: "Contador com CRC ativo para atendimento presencial",
    status: "pendente",
  },
  {
    clientName: "Escola de Idiomas",
    clientContact: "rh@escolaidiomas.com.br | (11) 3456-7893",
    serviceRequested: "Professor de Inglês",
    description: "Professor nativo ou fluente para aulas presenciais",
    status: "agendado",
  },
];

for (const req of recruitmentData) {
  await db.insert(schema.recruitmentRequests).values(req);
}
console.log(`✅ ${recruitmentData.length} solicitações de recrutamento criadas\n`);

// 8. Criar Reuniões Agendadas
console.log("📅 Criando reuniões agendadas...");
const recruitmentRequests = await db.select().from(schema.recruitmentRequests);
const meetingsData = [
  {
    recruitmentRequestId: recruitmentRequests.find(r => r.status === "agendado")?.id,
    title: "Reunião - Professor de Inglês",
    meetingDate: new Date(now.getTime() + 2 * 24 * 60 * 60 * 1000), // Daqui 2 dias
    location: "Escritório - Sala 3",
    description: "Levar currículo e certificados",
    status: "agendada",
  },
  {
    recruitmentRequestId: null,
    title: "Reunião de planejamento mensal",
    meetingDate: new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000), // Daqui 5 dias
    location: "Online - Google Meet",
    description: "Revisar metas do mês",
    status: "agendada",
  },
];

for (const meeting of meetingsData) {
  await db.insert(schema.meetings).values(meeting);
}
console.log(`✅ ${meetingsData.length} reuniões agendadas criadas\n`);

await connection.end();

console.log("🎉 Seed concluído com sucesso!");
console.log("\n📊 Resumo:");
console.log(`   - ${categoriesData.length} categorias`);
console.log(`   - ${productsData.length} produtos`);
console.log(`   - ${customersData.length} clientes`);
console.log(`   - ${salesCount} vendas`);
console.log(`   - ${expensesData.length} despesas`);
console.log(`   - ${accountsData.length} contas`);
console.log(`   - ${recruitmentData.length} solicitações de recrutamento`);
console.log(`   - ${meetingsData.length} reuniões agendadas`);
console.log("\n✨ O sistema está pronto para demonstração!");
